import { useEffect, useState, useRef, useCallback } from "react";
import { useDeviceConnection } from "@hooks/useDeviceConnection";
import { useDeviceStore } from "@store/useDeviceStore";

export default function KetNoi() {
  const { connected, connect, disconnect, sendAndWait } = useDeviceConnection();

  const setConnected = useDeviceStore((s) => s.setConnected);

  const [showPinModal, setShowPinModal] = useState(false);
  const [pin, setPin] = useState("");
  const [err, setErr] = useState("");
  const [fadeIn, setFadeIn] = useState(false);

  const connectingRef = useRef(false);

  /* ================= FADE ================= */
  useEffect(() => {
    const t = setTimeout(() => setFadeIn(true), 100);
    return () => clearTimeout(t);
  }, []);

  /* ================= BLE CONNECT ================= */
  const handleBleConnect = async () => {
    if (connectingRef.current) return;

    connectingRef.current = true;
    setErr("");

    try {
      const ok = await connect("ble");
      if (!ok) {
        setErr("Không tìm thấy thiết bị BLE");
      } else {
        setShowPinModal(true);
      }
    } catch (e) {
      console.error(e);
      setErr("Lỗi khi kết nối BLE");
    }

    connectingRef.current = false;
  };

  /* ================= SUBMIT PIN ================= */
  const handleSubmitPin = useCallback(async () => {
    if (pin.length !== 4) return;

    const encoder = new TextEncoder();
    const pinBytes = encoder.encode(pin);

    const oke = await sendAndWait(202, pinBytes);

    if (oke[0] === 1) {
      setPin("");
      setShowPinModal(false);
      setConnected(true);
    } else {
      setShowPinModal(false);
      disconnect();
      setErr("Sai mật khẩu!");
      setPin("");
    }
  }, [sendAndWait, pin]);

  if (connected) return null;

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-gradient-to-br from-purple-400 via-pink-300 to-indigo-500 px-5">
      {/* PIN MODAL */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-xs rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 text-center text-lg font-semibold">
              Nhập mật khẩu 4 số
            </div>

            <input
              type="password"
              inputMode="numeric"
              maxLength={4}
              value={pin}
              onChange={(e) => {
                const v = e.target.value
                  .replace(/\D/g, "") // chỉ cho số
                  .slice(0, 4); // giới hạn 4 ký tự

                setPin(v);
              }}
              className="w-full rounded-xl border p-4 text-center text-3xl tracking-widest"
              autoFocus
            />

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => {
                  setShowPinModal(false);
                  disconnect();
                }}
                className="flex-1 rounded-xl bg-gray-200 py-3"
              >
                Hủy
              </button>

              <button
                onClick={handleSubmitPin}
                className="flex-1 rounded-xl bg-indigo-600 py-3 text-white"
              >
                Xác nhận
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MAIN CARD */}
      <div
        className={`w-full max-w-sm transform rounded-3xl bg-white/90 p-8 text-center shadow-2xl backdrop-blur-xl transition-all duration-700 ${
          fadeIn ? "scale-100 opacity-100" : "scale-95 opacity-0"
        }`}
      >
        {/* LOGO ROW */}
        <div className="mb-6 flex items-center justify-center gap-6">
          <img src="/img/logo/ant.png" className="w-16 opacity-90" />
          <div className="h-10 w-[2px] bg-gray-300" />
          <img src="/img/logo/nvm.png" className="w-20 opacity-90" />
        </div>

        {/* TITLE */}
        <div className="mb-2 text-xl font-bold text-gray-800">
          NVM AUDIO FACTORY TOOL
        </div>

        <div className="mb-8 text-sm text-gray-500">
          Kết nối thiết bị qua BLE
        </div>

        {/* BLE BUTTON */}
        <button
          onClick={handleBleConnect}
          className={`w-full rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-4 text-lg font-semibold text-white shadow-lg transition active:scale-95 ${
            connectingRef.current ? "opacity-50" : ""
          }`}
        >
          {connectingRef.current ? "Đang kết nối..." : "Kết nối BLE"}
        </button>

        {/* ERROR */}
        {err && <div className="mt-6 text-sm text-red-500">{err}</div>}

        {/* FOOTER */}
        <div className="mt-10 text-xs tracking-widest text-gray-400">
          ANT × NVM Factory Tool v4.0
        </div>
      </div>
    </div>
  );
}
