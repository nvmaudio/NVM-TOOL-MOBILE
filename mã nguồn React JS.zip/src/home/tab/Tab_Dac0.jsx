import { useEffects } from "@hooks/useEffects";
import EffectRenderer from "@effects/EffectRenderer";

export default function Tab_Dac0() {
  const { effect_list } = useEffects();

  const groupEffects = effect_list?.filter((e) => e.group === 2) || [];

  return (
    <div className="bg-white rounded-2xl shadow m-3 p-2">
      {groupEffects.length === 0 ? (
        <p className="text-gray-500">Không có effect nào trong group 0.</p>
      ) : (
        <div className="flex flex-col items-center gap-3 overflow-y-auto">
          {groupEffects.map((effect) => (
            <div key={effect.index} className="w-full">
              <EffectRenderer effect_data={effect} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
