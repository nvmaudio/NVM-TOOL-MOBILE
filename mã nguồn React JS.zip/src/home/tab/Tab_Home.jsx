import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { Volume2, Music, Waves, Sparkles, Bluetooth } from "lucide-react";

import { useSystemConfig } from "@hooks/useSystemConfig";
import { useSTATUS } from "../../home/StatusBar/useSTATUS";
import { useEffectStore } from "@store/useEffectStore";

function VerticalSlider({
  label,
  min,
  max,
  value,
  onChange,
  icon: Icon,
  disabled = false,
  defaultValue,
}) {
  const percentage = Math.min(
    100,
    Math.max(0, ((value - min) / (max - min)) * 100),
  );

  const handleReset = () => {
    if (!disabled && defaultValue !== undefined) {
      onChange(defaultValue);
    }
  };

  return (
    <div
      className={`flex flex-col items-center gap-4 ${
        disabled ? "opacity-40" : ""
      }`}
    >
      <Icon size={18} className="text-white drop-shadow-md" />

      <div className="relative h-44 w-10">
        <input
          type="range"
          min={min}
          max={max}
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(Number(e.target.value))}
          style={{
            background: `linear-gradient(to right, ${
              disabled ? "rgba(255,255,255,0.1)" : "#3b82f6"
            } ${percentage}%, rgba(255,255,255,0.2) ${percentage}%)`,
          }}
          className={`
            absolute
            left-1/2
            top-1/2
            -translate-x-1/2
            -translate-y-1/2
            w-44
            h-2
            appearance-none
            rounded-full
            origin-center
            -rotate-90
            ${disabled ? "cursor-not-allowed" : "cursor-pointer"}
          `}
        />
      </div>

      <div className="text-white text-sm font-semibold tracking-wide">
        {label}
      </div>

      {/* 👇 Click để reset */}
      <div
        onClick={handleReset}
        className={`text-white/80 text-xs font-medium ${
          !disabled ? "cursor-pointer hover:text-white" : ""
        }`}
      >
        {value}
      </div>

      <style>
        {`
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          height: 25px;      /* tăng từ 18 → 28 */
          width: 25px;
          border-radius: 50%;
          background: white;
          box-shadow: 0 0 15px rgba(59, 130, 246, 0.8);
          transition: 0.2s ease;
          margin-top: -8px; /* chỉnh lại do thumb cao hơn */
          touch-action: manipulation;
        }

        input[type="range"]:active::-webkit-slider-thumb {
          transform: scale(1.2);
        }

        input[type="range"]:disabled::-webkit-slider-thumb {
          background: #999;
          box-shadow: none;
        }

        input[type="range"]::-webkit-slider-runnable-track {
          height: 8px;
          border-radius: 999px;
          background: transparent;
        }
      `}
      </style>
    </div>
  );
}

function GlassCard({ children, className }) {
  return (
    <div
      className={`
        backdrop-blur-2xl
        bg-gradient-to-br from-white/20 to-white/5
        border border-white/30
        rounded-3xl
        p-5
        shadow-[0_10px_40px_rgba(0,0,0,0.5)]
        flex flex-col
        ${className}
      `}
    >
      {children}
    </div>
  );
}

import { useVIRTUAL_BASS } from "./../../effects/VIRTUAL_BASS/useVIRTUAL_BASS";
import { useVIRTUAL_BASS_CLASSIC } from "./../../effects/VIRTUAL_BASS_CLASSIC/useVIRTUAL_BASS_CLASSIC";
import { useTHREE_D } from "./../../effects/THREE_D/useTHREE_D";

function VB({ Audio_mode, onClick }) {
  // Tính index an toàn
  const index = useMemo(() => {
    if (Audio_mode == null) return null;
    return [1, 4].includes(Audio_mode) ? 150 : 135;
  }, [Audio_mode]);

  const { data, loadVBedVB, setEnable } = useVIRTUAL_BASS(index);

  // Load khi có index hợp lệ
  useEffect(() => {
    if (index == null) return;
    loadVBedVB();
  }, [index, loadVBedVB]);

  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      if (!data) return;

      await setEnable(!data.enable);
      onClick?.(); // gọi nếu tồn tại
    },
    [data, setEnable, onClick],
  );

  const isActive = data?.enable ?? false;

  return (
    <button
      onClick={togglePower}
      disabled={index == null}
      className={`
        py-3 rounded-2xl text-sm font-semibold tracking-wide
        transition-all duration-200
        ${
          isActive
            ? "bg-blue-500 text-white shadow-lg shadow-blue-500/40 scale-105"
            : "bg-white/15 text-white hover:bg-white/25"
        }
        ${index == null ? "opacity-40 cursor-not-allowed" : ""}
      `}
    >
      VB Bass
    </button>
  );
}

function VBC({ Audio_mode, onClick }) {
  // Tính index an toàn
  const index = useMemo(() => {
    if (Audio_mode == null) return null;
    return [1, 4].includes(Audio_mode) ? 151 : 136;
  }, [Audio_mode]);

  const { data, loadVBClassic, setEnable } = useVIRTUAL_BASS_CLASSIC(index);

  // Load khi có index hợp lệ
  useEffect(() => {
    if (index == null) return;
    loadVBClassic();
  }, [index, loadVBClassic]);

  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      if (!data) return;

      await setEnable(!data.enable);

      console.log(data);

      onClick?.(); // gọi nếu tồn tại
    },
    [data, setEnable, onClick],
  );

  const isActive = data?.enable ?? false;

  return (
    <button
      onClick={togglePower}
      disabled={index == null}
      className={`
        py-3 rounded-2xl text-sm font-semibold tracking-wide
        transition-all duration-200
        ${
          isActive
            ? "bg-blue-500 text-white shadow-lg shadow-blue-500/40 scale-105"
            : "bg-white/15 text-white hover:bg-white/25"
        }
        ${index == null ? "opacity-40 cursor-not-allowed" : ""}
      `}
    >
      VB Bass Classic
    </button>
  );
}

function THREE_D({ onClick }) {
  const { data, load, setEnable } = useTHREE_D(137);

  // Load khi có index hợp lệ
  useEffect(() => {
    load();
  }, []);

  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      if (!data) return;

      await setEnable(!data.enable);
      onClick?.(); // gọi nếu tồn tại
    },
    [data, setEnable, onClick],
  );

  const isActive = data?.enable ?? false;

  return (
    <button
      onClick={togglePower}
      className={`
        py-3 rounded-2xl text-sm font-semibold tracking-wide
        transition-all duration-200
        ${
          isActive
            ? "bg-blue-500 text-white shadow-lg shadow-blue-500/40 scale-105"
            : "bg-white/15 text-white hover:bg-white/25"
        }
      `}
    >
      3D ảo
    </button>
  );
}

const STATUS_INDEX = 0x02;

export default function Tab_Home() {
  const sendTimeoutRef = useRef(null);
  const load_vol = useRef(false);
  const VolTimeoutRef = useRef(false);

  const [volume, setVolume] = useState(0);
  const [bass, setBass] = useState(16);
  const [mid, setMid] = useState(16);
  const [treble, setTreble] = useState(16);

  const { data, loadData, onData, sendEffect } = useSystemConfig();
  const { SYSInfo, loadSYS, setSysMode, setEffectMode } = useSTATUS();
  const clearEffectParams = useEffectStore((s) => s.clearEffectParams);

  const { Key_en, Vr_en, Pre_en, Pre_mode, Dongbo_volume, Audio_mode } = data;

  useEffect(() => {
    loadSYS();
    loadData();
  }, []);

  useEffect(() => {
    if (SYSInfo) {
      if (!load_vol.current) {
        setVolume(SYSInfo.volume);
        setBass(SYSInfo.bass);
        setMid(SYSInfo.mid);
        setTreble(SYSInfo.treb);
        load_vol.current = true;
      }
    }
  }, [SYSInfo]);

  useEffect(() => {
    const off = onData((packet) => {
      if (packet.cmd === 200) {
        if (!VolTimeoutRef.current) {
          setVolume(packet.data[0]);
          if (Pre_mode === 1) {
            setBass(packet.data[1]);
            setMid(packet.data[2]);
            setTreble(packet.data[3]);
          }
        }
      }
    });

    return off;
  }, [onData, Pre_mode]);

  const save_effect = useCallback(
    (type, v) => {
      if (sendTimeoutRef.current) {
        clearTimeout(sendTimeoutRef.current);
      }

      if (VolTimeoutRef.current) {
        clearTimeout(sendTimeoutRef.current);
      }

      sendTimeoutRef.current = setTimeout(() => {
        sendEffect(STATUS_INDEX, [3, type, v]);
        clearEffectParams(0x85);
      }, 100);

      VolTimeoutRef.current = setTimeout(() => {
        VolTimeoutRef.current = null;
      }, 3000);
    },
    [sendEffect, clearEffectParams],
  );

  return (
    <div
      id="tabhome"
      className="
        flex flex-col gap-6
        bg-gradient-to-br from-[#0f172a] via-[#1e293b] to-[#0f172a]
        text-white
        rounded-3xl
        p-6
        shadow-2xl
        m-3
      "
    >
      {/* SLIDER CARD */}
      <GlassCard className="flex-[3]">
        <div className="p-6 flex justify-around items-end">
          <VerticalSlider
            label="VOL"
            min={0}
            max={32}
            value={volume}
            onChange={(v) => {
              setVolume(v);
              save_effect(0, v); // type 0
            }}
            icon={Volume2}
            disabled={Dongbo_volume}
            defaultValue={0}
          />
          <VerticalSlider
            label="BASS"
            min={0}
            max={32}
            value={bass}
            onChange={(v) => {
              setBass(v);
              save_effect(1, v);
            }}
            icon={Music}
            disabled={!Pre_en || Pre_mode === 1}
            defaultValue={16}
          />
          <VerticalSlider
            label="MID"
            min={0}
            max={32}
            value={mid}
            onChange={(v) => {
              setMid(v);
              save_effect(2, v);
            }}
            icon={Waves}
            disabled={!Pre_en || Pre_mode === 1}
            defaultValue={16}
          />
          <VerticalSlider
            label="TRE"
            min={0}
            max={32}
            value={treble}
            onChange={(v) => {
              setTreble(v);
              save_effect(3, v);
            }}
            icon={Sparkles}
            disabled={!Pre_en || Pre_mode === 1}
            defaultValue={16}
          />
        </div>
      </GlassCard>

      {/* EFFECT CARD */}
      <GlassCard className="flex-[1]">
        <div className="grid grid-cols-3 gap-4">
          <VB Audio_mode={Audio_mode} />
          <VBC Audio_mode={Audio_mode} />
          <THREE_D Audio_mode={Audio_mode} />
        </div>
      </GlassCard>
    </div>
  );
}
