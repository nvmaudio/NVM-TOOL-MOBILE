import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import { useDeviceStore } from "@store/useDeviceStore";
import { useDeviceConnection } from "@hooks/useDeviceConnection";
import { useEffects } from "@hooks/useEffects";

import StatusBar from "./StatusBar";

import {
  SlidersHorizontal,
  AudioWaveform,
  Speaker,
  Subtitles,
  Settings2,
  Bluetooth,
  HomeIcon,
  BluetoothOff,
} from "lucide-react";

/* ================= TABS CONFIG ================= */
const tabs = [
  { id: "home", label: "Home", icon: HomeIcon, color: "blue" },
  { id: "gain", label: "Gain", icon: SlidersHorizontal, color: "emerald" },
  { id: "preamp", label: "Preamp", icon: AudioWaveform, color: "purple" },
  { id: "dac0", label: "R+L", icon: Speaker, color: "orange" },
  { id: "dacx", label: "SUB", icon: Subtitles, color: "pink" },
];

import Tab_Home from "./tab/Tab_Home";
import Tab_Gain_In from "./tab/Tab_Gain_In";
import Tab_Preamp from "./tab/Tab_Preamp";
import Tab_Dac0 from "./tab/Tab_Dac0";
import Tab_dacx from "./tab/Tab_dacx";

const tabMap = {
  home: Tab_Home,
  gain: Tab_Gain_In,
  preamp: Tab_Preamp,
  dac0: Tab_Dac0,
  dacx: Tab_dacx,
};

function bytesToString(bytes) {
  return String.fromCharCode(...bytes);
}

function bytesToHexString(bytes) {
  return Array.from(bytes)
    .reverse()
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

function hexStringToBytes(hex) {
  const bytes = [];
  for (let c = 0; c < hex.length; c += 2) {
    bytes.push(parseInt(hex.substr(c, 2), 16));
  }
  return new Uint8Array(bytes);
}

export default function Home() {
  const { mode } = useDeviceStore();
  const { connected, disconnect } = useDeviceConnection();
  const { sendAndWait } = useEffects();

  const nav = useNavigate();

  const [activeTab, setActiveTab] = useState("home");
  const [Board_name, setBoard_name] = useState("....");
  const [id, setID] = useState("....");

  /* ================= INIT ================= */
  useEffect(() => {
    const init = async () => {
      if (!connected) return;

      try {
        const payload = await sendAndWait(0x00);
        const chipId = bytesToHexString(payload);
        setID(chipId);

        const payload1 = await sendAndWait(0x01);
        setBoard_name(bytesToString(payload1));

        const activateCheck = await sendAndWait(0x02);

        if (activateCheck[0] === 0) {
          const res = await fetch(
            `https://nvmaudio.id.vn/api.php?action=get_chip_info&update=2&id_chip=${chipId}`,
          );
          const data = await res.json();

          if (data.error) {
            alert("Chip chưa đăng ký! ID: " + chipId);
            return;
          }

          const encBytes = hexStringToBytes(data.id_chip_enc_hex);
          await sendAndWait(0x00, encBytes);
        }
      } catch (e) {
        console.error(e);
      }
    };

    init();
  }, [connected, sendAndWait]);

  const ActiveTab = tabMap[activeTab] || (() => <p>Tab chưa có</p>);
  const iS_StatusBar = activeTab !== "home";

  /* ================= UI ================= */
  return (
    <div className="h-screen flex flex-col bg-slate-100 text-slate-800">
      {/* ================= HEADER ================= */}
      <div className="px-4 py-3 bg-white shadow-sm flex justify-between items-center">
        <div>
          <div className="text-lg font-bold">DSP Tool</div>
          <div className="text-xs text-slate-500 truncate max-w-[200px]">
            {Board_name} • {id}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {connected && (
            <div className="flex items-center gap-1 text-emerald-600 text-sm">
              <Bluetooth size={16} />
              {mode?.toUpperCase()}
            </div>
          )}

          <button
            onClick={() => nav("/caidat")}
            className="p-2 rounded-lg bg-blue-500 text-white"
          >
            <Settings2 size={18} />
          </button>

          {connected && (
            <button
              onClick={disconnect}
              className="p-2 rounded-lg bg-red-500 text-white"
            >
              <BluetoothOff size={18} />
            </button>
          )}
        </div>
      </div>

      {/* ================= CONTENT ================= */}
      <div className="flex-1 min-h-0 flex flex-col bg-slate-200">
        {/* Scrollable area */}
        <div
          className={`flex-1 min-h-0 ${
            iS_StatusBar ? "overflow-y-auto" : "overflow-hidden"
          }`}
        >
          <div className="pb-24">
            <ActiveTab />
          </div>
          {/* Status bar (fixed bottom inside content) */}
          {iS_StatusBar && (
            <div className="shrink-0 p-3 pb-[75px]">
              <StatusBar />
            </div>
          )}
        </div>
      </div>

      {/* ================= BOTTOM TAB BAR ================= */}
      <div className="fixed bottom-0 left-0 w-full bg-white border-t shadow-inner flex justify-around py-2">
        {tabs.map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;

          return (
            <button
              key={t.id}
              disabled={!connected}
              onClick={() => setActiveTab(t.id)}
              className={`flex flex-col items-center text-xs px-4 py-1 rounded-xl transition-all duration-200
                ${
                  isActive
                    ? `bg-blue-100 text-${t.color}-600 font-medium`
                    : `text-${t.color}-500`
                }
                ${!connected && "opacity-40"}
              `}
            >
              <Icon size={20} />
              {t.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
