import { useEffect, useState, useCallback } from "react";
import { usePCM_DELAY } from "./usePCM_DELAY";

export default function PCM_DELAY({ index, name }) {
  const { data, loadDelay, setEnable, setDelay, setMaxDelay, setHQ } =
    usePCM_DELAY(index);

  const [open, setOpen] = useState(false);

  const [local, setLocal] = useState({
    delay: 0,
    max_delay: 3000,
    high_quality: 0,
  });

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadDelay();
  }, [data, loadDelay]);

  /* ================= SYNC ================= */
  useEffect(() => {
    if (!data) return;

    setLocal((prev) => {
      if (
        prev.delay === data.delay &&
        prev.max_delay === data.max_delay &&
        prev.high_quality === data.high_quality
      ) {
        return prev;
      }

      return {
        delay: data.delay ?? 0,
        max_delay: data.max_delay ?? 3000,
        high_quality: data.high_quality ?? 0,
      };
    });
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      await setEnable(!enable);
    },
    [enable, setEnable],
  );

  /* ================= UPDATE ================= */

  const updateDelay = (v) => {
    let newVal = Math.max(0, v);
    newVal = Math.min(newVal, local.max_delay);

    setLocal((s) => ({ ...s, delay: newVal }));
    setDelay(newVal);
  };

  const updateMax = (v) => {
    let limit = local.high_quality ? 1000 : 3000;
    let newMax = Math.min(Math.max(0, v), limit);

    let newDelay = Math.min(local.delay, newMax);

    setLocal((s) => ({
      ...s,
      max_delay: newMax,
      delay: newDelay,
    }));

    setMaxDelay(newMax);
    if (newDelay !== local.delay) setDelay(newDelay);
  };

  const toggleHQ = () => {
    const newHQ = local.high_quality ? 0 : 1;
    const limit = newHQ ? 1000 : 3000;

    let newMax = Math.min(local.max_delay, limit);
    let newDelay = Math.min(local.delay, newMax);

    setLocal({
      delay: newDelay,
      max_delay: newMax,
      high_quality: newHQ,
    });

    setHQ(newHQ);
    setMaxDelay(newMax);
    if (newDelay !== local.delay) setDelay(newDelay);
  };

  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          <MobileRow
            label="Delay"
            value={local.delay}
            unit="ms"
            min={0}
            max={local.max_delay}
            enable={enable}
            onChange={updateDelay}
          />

          <MobileRow
            label="Max Delay"
            value={local.max_delay}
            unit="ms"
            min={0}
            max={local.high_quality ? 1000 : 3000}
            enable={enable}
            onChange={updateMax}
          />

          <ToggleRow
            label="High Mode"
            value={local.high_quality}
            enable={!enable}
            onToggle={toggleHQ}
          />
        </div>
      )}
    </div>
  );
}

/* ================= MOBILE ROW ================= */
function MobileRow({ label, value, unit, min, max, enable, onChange }) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleBlur = () => {
    if (display === "") return;

    let num = Number(display);
    if (isNaN(num)) return;

    num = Math.max(min ?? num, num);
    num = Math.min(max ?? num, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4 h-9">
      <div className="pl-2 text-sm font-medium">{label}</div>

      <div className="flex items-center gap-2">
        <input
          type="text"
          inputMode="decimal"
          value={display}
          disabled={!enable}
          onChange={(e) => setDisplay(e.target.value)}
          onBlur={handleBlur}
          className="
            w-24 h-9
            px-3
            text-center text-sm
            rounded-lg
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400
          "
        />

        <span className="text-xs text-gray-500 w-8">{unit ?? ""}</span>
      </div>
    </div>
  );
}


function ToggleRow({ label, value, enable, onToggle }) {
  return (
    <div className="flex items-center justify-between gap-4 h-9">
      <div className="pl-2 text-sm font-medium">{label}</div>

      <div className="flex items-center gap-2 h-9">
        <div className="w-24">
          <button
            disabled={!enable}
            onClick={() => onToggle(value ? 0 : 1)}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${value ? "bg-blue-500" : "bg-gray-300"}
          `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${value ? "translate-x-4" : "translate-x-1"}
            `}
            />
          </button>
        </div>

        <span className="text-xs text-gray-500 w-8"></span>
      </div>
    </div>
  );
}
