import { useEffect, useState, useRef, useCallback } from "react";
import { useEXPANDER } from "./useEXPANDER";

export default function Expander({ index, name }) {
  const {
    data,
    loadExpander,
    setEnable,
    setThreshold,
    setRatio,
    setAttack,
    setRelease,
  } = useEXPANDER(index);

  const [open, setOpen] = useState(false);

  const [local, setLocal] = useState({
    ratio: 1,
    threshold: 0,
    attack: 0,
    release: 0,
  });

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadExpander();
  }, [data, loadExpander]);

  /* ================= SYNC (ANTI GIẬT) ================= */
  useEffect(() => {
    if (!data) return;

    setLocal((prev) => {
      if (
        prev.ratio === data.ratio &&
        prev.threshold === data.threshold &&
        prev.attack === data.attack &&
        prev.release === data.release
      ) {
        return prev;
      }

      return {
        ratio: data.ratio ?? 1,
        threshold: data.threshold ?? 0,
        attack: data.attack ?? 0,
        release: data.release ?? 0,
      };
    });
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      await setEnable(!enable);
    },
    [enable, setEnable],
  );

  /* ================= UPDATE ================= */
  const update = (key, v) => {
    if (v === undefined || v === null || isNaN(v)) return;

    switch (key) {
      case "ratio":
        setRatio(v);
        break;
      case "threshold":
        setThreshold(Math.round(v * 100));
        break;
      case "attack":
        setAttack(v);
        break;
      case "release":
        setRelease(v);
        break;
      default:
        break;
    }
  };

  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          <MobileRow
            label="Ratio"
            value={local.ratio}
            min={1}
            max={10}
            step={1}
            enable={enable}
            onChange={(v) => update("ratio", v)}
          />

          <MobileRow1
            label="Threshold"
            value={local.threshold / 100}
            min={-90}
            max={0}
            step={0.1}
            unit="dB"
            enable={enable}
            onChange={(v) => update("threshold", v)}
          />

          <MobileRow
            label="Attack"
            value={local.attack}
            min={0}
            max={7500}
            unit="ms"
            enable={enable}
            onChange={(v) => update("attack", v)}
          />

          <MobileRow
            label="Release"
            value={local.release}
            min={0}
            max={7500}
            unit="ms"
            enable={enable}
            onChange={(v) => update("release", v)}
          />
        </div>
      )}
    </div>
  );
}

/* ================= MOBILE INPUT ================= */
function MobileRow({ label, value, min, max, unit, enable, onChange }) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4">
      {/* LABEL */}
      <div className="w-[120px] text-sm font-medium text-gray-700">{label}</div>

      {/* INPUT AREA */}
      <div className="flex items-center gap-2">
        <input
          type="text"
          inputMode="decimal"
          value={display}
          disabled={!enable}
          onChange={handleChange}
          onBlur={handleBlur}
          className="
            w-24 h-9 px-3
            text-center text-sm
            rounded-lg
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400
            disabled:bg-gray-100 disabled:text-gray-400
        "
        />

        {unit ? (
          <span className="text-xs text-gray-500 w-8 text-left">{unit}</span>
        ) : (
          <span className="text-xs text-gray-500 w-8 text-left"></span>
        )}
      </div>
    </div>
  );
}

function MobileRow1({
  label,
  value,
  min,
  max,
  step = 0.1,
  unit,
  enable = true,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? String(value) : "",
  );

  const isTypingRef = useRef(false);

  /* Sync từ ngoài vào nhưng không đè khi đang gõ */
  useEffect(() => {
    if (!isTypingRef.current) {
      if (value !== undefined && value !== null) {
        setDisplay(String(value));
      } else {
        setDisplay("");
      }
    }
  }, [value]);

  const isValidPartial = (v) => /^-?\d*\.?\d*$/.test(v);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!isValidPartial(v)) return;

    isTypingRef.current = true;
    setDisplay(v);

    // các trạng thái chưa hợp lệ
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) {
      onChange(num);
    }
  };

  const handleBlur = () => {
    isTypingRef.current = false;

    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    ) {
      setDisplay("");
      return;
    }

    let num = Number(display);

    if (isNaN(num)) {
      setDisplay("");
      return;
    }

    // Clamp
    if (typeof min === "number") num = Math.max(min, num);
    if (typeof max === "number") num = Math.min(max, num);

    // Snap theo step
    if (typeof step === "number" && step > 0) {
      const precision = (step.toString().split(".")[1] || "").length;
      num = Math.round(num / step) * step;
      num = Number(num.toFixed(precision));
    }

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4">
      {/* LABEL */}
      <div className="w-[120px] text-sm font-medium text-gray-700">{label}</div>

      {/* INPUT AREA */}
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={display}
          disabled={!enable}
          onFocus={() => (isTypingRef.current = true)}
          onChange={handleChange}
          onBlur={handleBlur}
          className="
            w-24 h-9 px-3
            text-center text-sm
            rounded-lg
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400
            disabled:bg-gray-100 disabled:text-gray-400
          "
        />

        <span className="text-xs text-gray-500 w-8 text-left">
          {unit ?? ""}
        </span>
      </div>
    </div>
  );
}
