import { useEffect, useState, useCallback } from "react";
import { usePHASE_CONTROL } from "./usePHASE_CONTROL";

export default function PHASE_CONTROL({ index, name }) {
  const { data, loadPhase, setEnable, setPhase } = usePHASE_CONTROL(index);

  const [open, setOpen] = useState(false);
  const [localPhase, setLocalPhase] = useState(0);

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadPhase();
  }, [data, loadPhase]);

  /* ================= SYNC ================= */
  useEffect(() => {
    if (!data) return;

    setLocalPhase((prev) => (prev === data.phase ? prev : (data.phase ?? 0)));
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      await setEnable(!enable);
    },
    [enable, setEnable],
  );

  /* ================= UPDATE ================= */
  const update = (v) => {
    setLocalPhase(v);
    setPhase(v);
  };

  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          <SelectRow
            label="Phase"
            value={localPhase}
            enable={enable}
            options={[
              { label: "Normal", value: 0 },
              { label: "Invert 180°", value: 1 },
            ]}
            onChange={update}
          />
        </div>
      )}
    </div>
  );
}

/* ================= SELECT ROW – SYSTEM ================= */
function SelectRow({ label, value, options, enable, onChange }) {
  return (
    <div className="flex items-center justify-between gap-4 h-9">
      <div className="w-[120px] text-sm font-medium text-gray-700">{label}</div>

      <select
        value={value}
        disabled={!enable}
        onChange={(e) => onChange(Number(e.target.value))}
        className="
          w-32 h-9
          px-3
          text-sm
          text-center
          rounded-lg
          bg-white
          border border-gray-300
          focus:outline-none
          focus:ring-2
          focus:ring-green-400
        "
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}
