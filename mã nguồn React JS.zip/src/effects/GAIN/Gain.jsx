import { useEffect, useState, useRef, useCallback } from "react";

import { useGain } from "./useGain";

export default function Gain({ index, name }) {
  const { data, loadGain, setGainEnable, setGainVolume } = useGain(index);

  const [open, setOpen] = useState(false);
  const [localVolume, setLocalVolume] = useState(0);
  const debounceRef = useRef(null);

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadGain();
  }, [data, loadGain]);

  /* ================= SYNC ================= */
  useEffect(() => {
    if (!data) return;

    setLocalVolume((prev) => {
      if (prev === data.volume) return prev;
      return data.volume ?? -60;
    });
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      await setGainEnable(!enable);
    },
    [enable, setGainEnable],
  );

  /* ================= DEBOUNCE SEND ================= */
  const sendVolume = useCallback(
    (v) => {
      clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        setGainVolume(v);
      }, 100);
    },
    [setGainVolume],
  );

  const clamp = (v) => Math.max(-60, Math.min(12, v));
  const round2 = (v) => Math.round(Number(v) * 100) / 100;

  const update = (v) => {
    if (v === undefined || v === null || isNaN(v)) return;

    const value = clamp(round2(v));
    setLocalVolume(value);
    sendVolume(value);
  };

  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          {/* VALUE DISPLAY */}
          <div className="flex items-center justify-between">
            <div className="pl-2 text-sm font-medium">Volume</div>
            <div className="text-sm text-gray-600">
              {localVolume.toFixed(2)} dB
            </div>
          </div>

          {/* SLIDER */}
          <input
            type="range"
            min={-60}
            max={12}
            step={0.1}
            value={localVolume.toFixed(2)}
            onChange={(e) => update(e.target.value)}
            disabled={!enable}
            className="w-full h-2 accent-blue-500"
          />

          {/* INPUT (Mobile style) */}
          <MobileInput
            value={localVolume}
            min={-60}
            max={12}
            step={0.1}
            unit="dB"
            enable={enable}
            onChange={update}
          />
        </div>
      )}
    </div>
  );
}

function MobileInput({
  value,
  min,
  max,
  step = 0.1,
  unit,
  enable = true,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? String(value) : "",
  );

  const isTypingRef = useRef(false);

  /* Sync từ ngoài vào nhưng KHÔNG ghi đè khi user đang gõ */
  useEffect(() => {
    if (!isTypingRef.current) {
      if (value !== undefined && value !== null) {
        setDisplay(Number(value).toFixed(2));
      } else {
        setDisplay("");
      }
    }
  }, [value]);

  const isValidPartial = (v) => /^-?\d*\.?\d*$/.test(v);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!isValidPartial(v)) return;

    isTypingRef.current = true;
    setDisplay(v);

    // Các trạng thái chưa hợp lệ
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) {
      onChange(num);
    }
  };

  const handleBlur = () => {
    isTypingRef.current = false;

    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    ) {
      setDisplay("");
      return;
    }

    let num = Number(display);

    if (isNaN(num)) {
      setDisplay("");
      return;
    }

    // Clamp
    if (typeof min === "number") num = Math.max(min, num);
    if (typeof max === "number") num = Math.min(max, num);

    // Snap theo step
    if (typeof step === "number" && step > 0) {
      const precision = (step.toString().split(".")[1] || "").length;
      num = Math.round(num / step) * step;
      num = Number(num.toFixed(precision));
    }

    setDisplay(num.toFixed(2));
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4">
      <div className="pl-2 text-sm font-medium">Value</div>

      <div className="flex items-center gap-2">
        <input
          type="text"
          value={display}
          disabled={!enable}
          onChange={handleChange}
          onFocus={() => (isTypingRef.current = true)}
          onBlur={handleBlur}
          className="
            w-24 px-3 py-2 text-center rounded-lg text-sm
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400
            disabled:bg-gray-100 disabled:text-gray-400
          "
        />

        <span className="text-xs text-gray-500 w-8 text-left">
          {unit ?? ""}
        </span>
      </div>
    </div>
  );
}
