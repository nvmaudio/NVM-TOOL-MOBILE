import { useEffect, useState, useMemo, useRef } from "react";
import { useEQ } from "./useEQ";
import EQGraph from "./EQGraph";

/* ================= FILTER TYPES ================= */

export const EQ_FILTER_TYPES = [
  { label: "PK", value: 0 },
  { label: "LS", value: 1 },
  { label: "HS", value: 2 },
  { label: "LPF", value: 3 },
  { label: "HPF", value: 4 },
  { label: "BPF", value: 5 },
  { label: "NOTCH", value: 6 },
];

/* ================= SAFE NUMBER INPUT ================= */

function SafeNumberInput({
  value,
  min,
  max,
  decimals, // ví dụ Q = 3
  disabled,
  onChangeFast,
  onCommit,
}) {
  const [display, setDisplay] = useState(
    value !== undefined ? String(value) : "",
  );

  useEffect(() => {
    if (value === undefined) return;
    setDisplay(String(value));
  }, [value]);

  const handleChange = (e) => {
    let v = e.target.value;

    if (v === "") {
      setDisplay("");
      return;
    }

    // Chỉ cho số và dấu .
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    // 🔥 Giới hạn số thập phân ngay khi nhập
    if (decimals !== undefined && v.includes(".")) {
      const [int, dec] = v.split(".");
      if (dec.length > decimals) {
        v = int + "." + dec.slice(0, decimals);
      }
    }

    setDisplay(v);

    const num = Number(v);
    if (!isNaN(num)) {
      onChangeFast?.(num);
    }
  };

  const handleBlur = () => {
    if (display === "" || display === "-" || display === ".") {
      setDisplay(String(value ?? 0));
      return;
    }

    let num = Number(display);
    if (isNaN(num)) num = 0;

    if (min !== undefined) num = Math.max(min, num);
    if (max !== undefined) num = Math.min(max, num);

    if (decimals !== undefined) {
      num = Number(num.toFixed(decimals));
    }

    setDisplay(String(num));
    onCommit?.(num);
  };

  return (
    <input
      type="text"
      inputMode="decimal"
      value={display}
      disabled={disabled}
      onChange={handleChange}
      onBlur={handleBlur}
      className="w-full bg-white border rounded-lg px-2 py-1 shadow-sm text-right"
    />
  );
}

function SafeNumberInput1({
  value,
  min,
  max,
  decimals, // ví dụ Q = 3
  disabled,
  onChangeFast,
  onCommit,
}) {
  const [display, setDisplay] = useState(
    value !== undefined ? String(value) : "",
  );

  useEffect(() => {
    if (value === undefined) return;
    setDisplay(String(value));
  }, [value]);

  const handleChange = (e) => {
    let v = e.target.value;

    if (v === "") {
      setDisplay("");
      return;
    }

    // Chỉ cho số và dấu .
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    // 🔥 Giới hạn số thập phân ngay khi nhập
    if (decimals !== undefined && v.includes(".")) {
      const [int, dec] = v.split(".");
      if (dec.length > decimals) {
        v = int + "." + dec.slice(0, decimals);
      }
    }

    setDisplay(v);

    const num = Number(v);
    if (!isNaN(num)) {
      onChangeFast?.(num);
    }
  };

  const handleBlur = () => {
    if (display === "" || display === "-" || display === ".") {
      setDisplay(String(value ?? 0));
      return;
    }

    let num = Number(display);
    if (isNaN(num)) num = 0;

    if (min !== undefined) num = Math.max(min, num);
    if (max !== undefined) num = Math.min(max, num);

    if (decimals !== undefined) {
      num = Number(num.toFixed(decimals));
    }

    setDisplay(String(num));
    onCommit?.(num);
  };

  return (
    <input
      type="text"
      value={display}
      disabled={disabled}
      onChange={handleChange}
      onBlur={handleBlur}
      className="w-24 bg-white border rounded-lg px-2 py-1 shadow-sm text-right"
    />
  );
}

/* ================= COMPONENT ================= */

export default function EQ({ index, name }) {
  const { data, loadEQ, setEQEnable, setPregain, setFilterFieldFast } =
    useEQ(index);

  const [draft, setDraft] = useState(null);
  const [open, setOpen] = useState(false);

  const loadedRef = useRef(false);
  const pregainDebounce = useRef(null);
  const fastSendRef = useRef({});

  /* ===== LOAD ===== */

  useEffect(() => {
    if (!data) loadEQ();
  }, [data, loadEQ]);

  useEffect(() => {
    if (data && !loadedRef.current) {
      const clone = JSON.parse(JSON.stringify(data));

      clone.filters = clone.filters.map((f) => ({
        ...f,
        Q: Math.round((Number(f.Q) + Number.EPSILON) * 1000) / 1000,
      }));

      clone.pregain =
        Math.round((Number(clone.pregain) + Number.EPSILON) * 100) / 100;

      setDraft(clone);
      loadedRef.current = true;
    }
  }, [data]);

  const enable = draft?.enable ?? false;

  /* ================= POWER ================= */

  const togglePower = async (e) => {
    e.stopPropagation();
    await setEQEnable(!enable);
    setDraft((d) => ({ ...d, enable: !enable }));
  };

  /* ================= PREGAIN ================= */

  const updatePregain = (v) => {
    setDraft((d) => ({ ...d, pregain: v }));

    clearTimeout(pregainDebounce.current);
    pregainDebounce.current = setTimeout(() => {
      setPregain(v);
    }, 120);
  };

  /* ================= FILTER ================= */

  const throttleFastSend = (band, field, value) => {
    if (!fastSendRef.current[band]) fastSendRef.current[band] = {};

    clearTimeout(fastSendRef.current[band][field]);

    fastSendRef.current[band][field] = setTimeout(() => {
      setFilterFieldFast(band, field, value);
    }, 250);
  };

  const updateFilter = (band, field, value) => {
    if (field === "f0") value = Math.max(20, Math.min(20000, value));

    if (field === "gain") value = Math.max(-12, Math.min(12, value));

    if (field === "Q") {
      value = Math.max(0.01, Math.min(10, value));
      value = Math.round(value * 1000) / 1000;
    }

    setDraft((d) => {
      const copy = { ...d, filters: [...d.filters] };
      const f = { ...copy.filters[band], [field]: value };
      copy.filters[band] = f;

      if (["gain", "Q", "f0", "type"].includes(field)) {
        throttleFastSend(band, field, value);
      }

      if (field === "enable") {
        throttleFastSend(band, "enable", value);
      }

      return copy;
    });
  };

  const updateFilter1 = (band, field, value) => {
    if (field === "Q" && value <= 0) value = 0.001;

    setDraft((d) => {
      const copy = { ...d, filters: [...d.filters] };
      copy.filters[band] = {
        ...copy.filters[band],
        [field]: value,
      };

      if (["gain", "Q", "f0"].includes(field)) {
        throttleFastSend(band, field, value);
      }

      return copy;
    });
  };

  const activeFilters = useMemo(() => {
    if (!draft) return [];
    return draft.filters
      .map((f, i) => ({ ...f, band: i }))
      .filter((f) => f.enable);
  }, [draft]);

  if (!data || !draft)
    return <div className="p-3 text-sm text-gray-400">Loading {name}...</div>;

  /* ================= UI ================= */

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`${open ? "rotate-180" : ""}`}>▾</div>
      </div>

      {open && (
        <div
          className={`p-3 space-y-3 ${!enable ? "opacity-60 pointer-events-none" : ""}`}
        >
          {/* GRAPH */}
          <div className="w-full bg-[#0f2a35] p-2 rounded-xl">
            <EQGraph
              filters={activeFilters}
              pregain={draft.pregain}
              onDrag={(band, v) => {
                if (v.f0 !== undefined) updateFilter(band, "f0", v.f0);
                if (v.gain !== undefined) updateFilter(band, "gain", v.gain);
              }}
            />
          </div>

          {/* PREGAIN */}
          <div className="bg-gray-100 border rounded-xl p-3">
            <div className="font-semibold mb-2 text-xs">Pre-Gain</div>

            <div className="flex items-center gap-3">
              <input
                type="range"
                min={-96}
                max={18}
                step={0.1}
                value={draft.pregain}
                onChange={(e) => updatePregain(Number(e.target.value))}
                className="flex-1"
              />

              <SafeNumberInput1
                value={draft.pregain}
                min={-60}
                max={12}
                decimals={2}
                disabled={!enable}
                onChangeFast={(v) => setDraft((d) => ({ ...d, pregain: v }))}
                onCommit={(v) => updatePregain(v)}
              />
              dB
            </div>
          </div>

          {/* FILTER ENABLE */}
          <div className="bg-gray-100 border rounded-xl p-3">
            <div className="flex flex-wrap gap-2">
              {draft.filters.map((f, i) => (
                <button
                  key={i}
                  onClick={() => updateFilter(i, "enable", !f.enable)}
                  className={`px-2 py-1 text-xs rounded-lg border transition
                    ${f.enable ? "bg-blue-500 text-white" : "bg-gray-200"}
                  `}
                >
                  F{i}
                </button>
              ))}
            </div>
          </div>

          {/* TABLE */}
          <div className="border rounded-xl overflow-hidden text-sm bg-white">
            <div className="grid grid-cols-[25px_60px_1fr_1fr_1fr] bg-gray-100 px-4 py-2 font-semibold text-gray-700 text-center">
              <div>Band</div>
              <div>Type</div>
              <div>Fc</div>
              <div>Gain</div>
              <div>Q</div>
            </div>

            {draft.filters
              .map((f, i) => ({ ...f, band: i }))
              .filter((f) => f.enable)
              .map((f) => (
                <div
                  key={f.band}
                  className="grid grid-cols-[25px_60px_1fr_1fr_1fr] items-center gap-x-2 px-4 py-2 border-t"
                >
                  <div>F{f.band}</div>

                  <select
                    value={f.type}
                    onChange={(e) =>
                      updateFilter(f.band, "type", Number(e.target.value))
                    }
                    className="w-full bg-white border rounded-lg px-2 py-1"
                  >
                    {EQ_FILTER_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>

                  <SafeNumberInput
                    value={f.f0}
                    min={20}
                    max={20000}
                    decimals={0}
                    disabled={!enable}
                    onChangeFast={(v) => updateFilter1(f.band, "f0", v)}
                    onCommit={(v) => updateFilter(f.band, "f0", v)}
                  />

                  <SafeNumberInput1
                    value={f.gain}
                    min={-12}
                    max={12}
                    decimals={2}
                    disabled={!enable}
                    onChangeFast={(v) => updateFilter1(f.band, "gain", v)}
                    onCommit={(v) => updateFilter(f.band, "gain", v)}
                  />

                  <SafeNumberInput
                    value={f.Q}
                    min={0.01}
                    max={10}
                    decimals={3}
                    disabled={!enable}
                    onChangeFast={(v) => updateFilter1(f.band, "Q", v)}
                    onCommit={(v) => updateFilter(f.band, "Q", v)}
                  />
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
