import { useEffect, useRef, useState } from "react";

/* ================= CONST ================= */

const HEIGHT = 200;
const Fs = 48000;

const MIN_FREQ = 20;
const MAX_FREQ = 22000;
const MIN_GAIN = -12;
const MAX_GAIN = 12;

const FREQ_LINES = [
  20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 15000, 20000,
];

const GAIN_LINES = [-12, -10, -8, -6, -4, -2, 0, 2, 4, 6, 8, 10, 12];

function formatFreq(f) {
  if (f >= 1000) return f / 1000 + "k";
  return f + "";
}

/* ================= COMPONENT ================= */

export default function EQGraph({ filters, pregain, onDrag }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  const [width, setWidth] = useState(300);
  const [drag, setDrag] = useState(null);

  /* ================= SCALE ================= */

  function freqToX(f) {
    return (Math.log10(f / MIN_FREQ) / Math.log10(MAX_FREQ / MIN_FREQ)) * width;
  }

  function xToFreq(x) {
    return MIN_FREQ * Math.pow(MAX_FREQ / MIN_FREQ, x / width);
  }

  function gainToY(g) {
    return HEIGHT - ((g - MIN_GAIN) / (MAX_GAIN - MIN_GAIN)) * HEIGHT;
  }

  function yToGain(y) {
    return MIN_GAIN + ((HEIGHT - y) / HEIGHT) * (MAX_GAIN - MIN_GAIN);
  }

  /* ================= RBJ COEFF ================= */

  function biquadCoeff(f) {
    const A = Math.pow(10, f.gain / 40);
    const w0 = (2 * Math.PI * f.f0) / Fs;
    const cos = Math.cos(w0);
    const sin = Math.sin(w0);
    const Q = Math.max(0.001, f.Q || 0.707);
    const alpha = sin / (2 * Q);

    let b0, b1, b2, a0, a1, a2;

    switch (f.type) {
      /* PK */
      case 0:
        b0 = 1 + alpha * A;
        b1 = -2 * cos;
        b2 = 1 - alpha * A;
        a0 = 1 + alpha / A;
        a1 = -2 * cos;
        a2 = 1 - alpha / A;
        break;

      /* LS */
      case 1: {
        const s = Math.sqrt(A) / Q;
        b0 = A * (A + 1 - (A - 1) * cos + s * sin);
        b1 = 2 * A * (A - 1 - (A + 1) * cos);
        b2 = A * (A + 1 - (A - 1) * cos - s * sin);
        a0 = A + 1 + (A - 1) * cos + s * sin;
        a1 = -2 * (A - 1 + (A + 1) * cos);
        a2 = A + 1 + (A - 1) * cos - s * sin;
        break;
      }

      /* HS */
      case 2: {
        const s = Math.sqrt(A) / Q;
        b0 = A * (A + 1 + (A - 1) * cos + s * sin);
        b1 = -2 * A * (A - 1 + (A + 1) * cos);
        b2 = A * (A + 1 + (A - 1) * cos - s * sin);
        a0 = A + 1 - (A - 1) * cos + s * sin;
        a1 = 2 * (A - 1 - (A + 1) * cos);
        a2 = A + 1 - (A - 1) * cos - s * sin;
        break;
      }

      /* LPF */
      case 3:
        b0 = (1 - cos) / 2;
        b1 = 1 - cos;
        b2 = (1 - cos) / 2;
        a0 = 1 + alpha;
        a1 = -2 * cos;
        a2 = 1 - alpha;
        break;

      /* HPF */
      case 4:
        b0 = (1 + cos) / 2;
        b1 = -(1 + cos);
        b2 = (1 + cos) / 2;
        a0 = 1 + alpha;
        a1 = -2 * cos;
        a2 = 1 - alpha;
        break;

      /* BPF */
      case 5:
        b0 = sin / 2;
        b1 = 0;
        b2 = -sin / 2;
        a0 = 1 + alpha;
        a1 = -2 * cos;
        a2 = 1 - alpha;
        break;

      /* NOTCH */
      case 6:
        b0 = 1;
        b1 = -2 * cos;
        b2 = 1;
        a0 = 1 + alpha;
        a1 = -2 * cos;
        a2 = 1 - alpha;
        break;

      /* 1st order fake */
      case 7:
      case 8:
        return null;

      default:
        return null;
    }

    return {
      b0: b0 / a0,
      b1: b1 / a0,
      b2: b2 / a0,
      a1: a1 / a0,
      a2: a2 / a0,
    };
  }

  /* ================= MAG ================= */

  function magnitude(c, f) {
    const w = (2 * Math.PI * f) / Fs;

    const cos = Math.cos(w);
    const sin = Math.sin(w);

    const num =
      (c.b0 + c.b1 * cos + c.b2 * Math.cos(2 * w)) ** 2 +
      (c.b1 * sin + c.b2 * Math.sin(2 * w)) ** 2;

    const den =
      (1 + c.a1 * cos + c.a2 * Math.cos(2 * w)) ** 2 +
      (c.a1 * sin + c.a2 * Math.sin(2 * w)) ** 2;

    return Math.sqrt(num / den);
  }

  /* ================= DRAW ================= */

  function draw() {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");

    ctx.clearRect(0, 0, width, HEIGHT);

    /* GRID */

    ctx.strokeStyle = "#28444f";
    ctx.fillStyle = "#7fa5b3";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "center";

    FREQ_LINES.forEach((freq) => {
      const x = freqToX(freq);

      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, HEIGHT);
      ctx.stroke();

      ctx.fillText(formatFreq(freq), x, HEIGHT - 4);
    });

    GAIN_LINES.forEach((g) => {
      const y = gainToY(g);

      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();

      ctx.fillText((g > 0 ? "+" : "") + g + " dB", 15, y);
    });

    /* RESPONSE */

    const N = 2048;
    ctx.beginPath();

    for (let i = 0; i < N; i++) {
      const freq = MIN_FREQ * Math.pow(MAX_FREQ / MIN_FREQ, i / N);

      let mag = 1;

      filters.forEach((f) => {
        const c = biquadCoeff(f);
        if (!c) return;
        mag *= magnitude(c, freq);
      });

      mag *= Math.pow(10, pregain / 20);

      const db = 20 * Math.log10(mag);

      const x = freqToX(freq);
      const y = gainToY(db);

      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }

    ctx.strokeStyle = "#00e0ff";
    ctx.lineWidth = 2;
    ctx.stroke();

    /* NODES */

    /* NODES */

    filters.forEach((f) => {
      const x = freqToX(f.f0);
      const y = gainToY(f.gain);

      // circle
      ctx.fillStyle = "#ffd400";
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fill();

      // text
      ctx.fillStyle = "white";
      ctx.font = "11px sans-serif";
      ctx.textAlign = "center";

      const freqText =
        f.f0 >= 1000 ? (f.f0 / 1000).toFixed(1) + " kHz" : f.f0 + " Hz";

      ctx.fillText(`F${f.band}`, x, y - 18);
      ctx.fillText(freqText, x, y - 6);
    });
  }

  useEffect(draw, [filters, pregain, width]);

  /* ================= RESIZE OBSERVER ================= */

  useEffect(() => {
    if (!containerRef.current) return;

    const observer = new ResizeObserver((entries) => {
      const newWidth = entries[0].contentRect.width;
      setWidth(newWidth);
    });

    observer.observe(containerRef.current);

    return () => observer.disconnect();
  }, []);

  /* ================= POINTER ================= */

  function pointerDown(e) {
    const rect = canvasRef.current.getBoundingClientRect();

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    filters.forEach((f, i) => {
      const dx = freqToX(f.f0) - x;
      const dy = gainToY(f.gain) - y;

      if (Math.hypot(dx, dy) < 14) {
        setDrag(i);
      }
    });
  }

  function pointerMove(e) {
    if (drag == null) return;

    const rect = canvasRef.current.getBoundingClientRect();

    const x = e.clientX - rect.left;

    const clampedX = Math.max(0, Math.min(width, x));

    const newFreq = Math.round(xToFreq(clampedX));

    // ❌ bỏ gain thay đổi
    onDrag(filters[drag].band, {
      f0: newFreq,
      gain: filters[drag].gain, // giữ nguyên gain
    });
  }

  function pointerUp() {
    setDrag(null);
  }

  /* ================= RENDER ================= */

  return (
    <div ref={containerRef} style={{ width: "100%" }}>
      <canvas
        ref={canvasRef}
        width={width}
        height={HEIGHT}
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          pointerDown(e);
        }}
        onPointerMove={pointerMove}
        onPointerUp={pointerUp}
        onPointerCancel={pointerUp}
        style={{
          width: "100%",
          height: HEIGHT,
          background: "#0f2a35",
          borderRadius: 8,
          touchAction: "none",
          cursor: drag != null ? "grabbing" : "grab",
        }}
      />
    </div>
  );
}
