import { useEffect, useState, useMemo, useRef } from "react";
import { useEQ } from "./useEQ";
import EQGraph from "./EQGraph";

import { useSystemConfig } from "@hooks/useSystemConfig";

/* ================= FILTER TYPES ================= */

export const EQ_FILTER_TYPES = [
  { label: "PK", value: 0 },
  { label: "LS", value: 1 },
  { label: "HS", value: 2 },
  //  { label: "LPF", value: 3 },
  //  { label: "HPF", value: 4 },
  //  { label: "BPF", value: 5 },
  //  { label: "NOTCH", value: 6 },
];

/* ================= COMPONENT ================= */

const calcGainFromVR = (vrGain, buocEq) => {
  const gainDb = ((vrGain - 16) / 16) * buocEq;
  return gainDb; // giữ dạng dB cho UI
};

export default function EQ({ index, name }) {
  const {
    data,
    loadEQ,
    clearEffectParams,
    setEQEnable,
    setPregain,
    setFilterParam,
    setFilterFieldFast,
  } = useEQ(index);

  const { data: sys, onData, pushVrLog } = useSystemConfig();

  const { Volume_tong, Nho_volume, Dongbo_volume, Vr_log, Pre_mode } = sys;

  const [draft, setDraft] = useState(null);
  const [open, setOpen] = useState(false);

  const loadedRef = useRef(false);
  const fastSendRef = useRef({});

  /* ===== LOAD ===== */
  useEffect(() => {
    if (!data) loadEQ();
  }, [data, loadEQ]);

  useEffect(() => {
    const off = onData((packet) => {
      if (packet.cmd === 200) {
        pushVrLog(packet.data);
        console.log(packet.data);
      }
    });

    return off;
  }, [onData]);

  useEffect(() => {
    if (!sys?.Vr_log || !loadedRef.current) return;

    setDraft((prev) => {
      if (!prev) return prev;

      const copy = { ...prev };
      copy.filters = [...copy.filters];

      const buocEq = sys.Buoc_eq ?? 12;

      const enabledFilters = copy.filters
        .map((f, i) => ({ ...f, index: i }))
        .filter((f) => f.enable)
        .sort((a, b) => a.f0 - b.f0);

      // Bass
      if (enabledFilters[0] && sys.Vr_log?.[1] != null) {
        copy.filters[enabledFilters[0].index].gain = calcGainFromVR(
          sys.Vr_log[1],
          buocEq,
        );
      }

      // Mid
      if (enabledFilters[1] && sys.Vr_log?.[2] != null) {
        copy.filters[enabledFilters[1].index].gain = calcGainFromVR(
          sys.Vr_log[2],
          buocEq,
        );
      }

      // Treble
      if (enabledFilters[2] && sys.Vr_log?.[3] != null) {
        copy.filters[enabledFilters[2].index].gain = calcGainFromVR(
          sys.Vr_log[3],
          buocEq,
        );
      }

      return copy;
    });
  }, [sys?.Vr_log]);

  /* ===== DEVICE → DRAFT ===== */
  useEffect(() => {
    if (data && !loadedRef.current) {
      setDraft(JSON.parse(JSON.stringify(data)));
      loadedRef.current = true;
    }
  }, [data]);

  const enable = draft?.enable ?? false;

  /* ================= POWER ================= */

  const togglePower = async (e) => {
    e.stopPropagation();
    await setEQEnable(!enable);

    setDraft((d) => ({
      ...d,
      enable: !enable,
    }));
  };

  /* ================= FILTER ================= */

  const throttleFastSend = (band, field, value) => {
    if (!fastSendRef.current[band]) {
      fastSendRef.current[band] = {};
    }
    clearTimeout(fastSendRef.current[band][field]);
    fastSendRef.current[band][field] = setTimeout(() => {
      setFilterFieldFast(band, field, value);
    }, 250);
  };

  const updateFilter = (band, field, value) => {
    if (field === "f0") {
      value = Math.max(20, Math.min(20000, value));
    }

    if (field === "gain") {
      value = Math.max(-12, Math.min(12, value));
    }

    const round3 = (v) => Math.round(v * 1000) / 1000;
    if (field === "Q") {
      value = Math.max(0.01, Math.min(10, value));
      value = round3(value);
    }

    setDraft((d) => {
      const copy = { ...d };
      copy.filters = [...copy.filters];

      const f = {
        ...copy.filters[band],
        [field]: value,
      };

      copy.filters[band] = f;

      // ===== AUTO INIT WHEN ENABLE =====
      if (field === "enable") {
        if (value === true) {
          if (copy.filters[band].f0 === 0) {
            const prev = copy.filters[band - 1];
            const baseFreq = prev ? prev.f0 : 1000;
            f.f0 = Math.min(baseFreq + 1000, 20000);
            f.gain = 0;
            f.Q = 0.707;
            f.type = 0;
          }

          throttleFastSend(band, "enable", value);
          throttleFastSend(band, "f0", f.f0);
          throttleFastSend(band, "gain", f.gain);
          throttleFastSend(band, "Q", f.Q);
          throttleFastSend(band, "type", f.type);
        }
      }

      // ===== REALTIME =====
      if (field === "gain" || field === "Q" || field === "f0") {
        throttleFastSend(band, field, value);
      }

      if (field === "type") {
        throttleFastSend(band, field, value);
      }

      return copy;
    });
  };

  const updateFilter1 = (band, field, value) => {
    if (field === "Q") {
      if (value <= 0) {
        value = 0.001;
      }
    }

    setDraft((d) => {
      const copy = { ...d };
      copy.filters = [...copy.filters];

      const f = {
        ...copy.filters[band],
        [field]: value,
      };

      copy.filters[band] = f;

      // ===== AUTO INIT WHEN ENABLE =====
      if (field === "enable") {
        if (value === true) {
          if (copy.filters[band].f0 === 0) {
            const prev = copy.filters[band - 1];
            const baseFreq = prev ? prev.f0 : 1000;
            f.f0 = Math.min(baseFreq + 1000, 20000);
            f.gain = 0;
            f.Q = 0.707;
            f.type = 0;
          }

          throttleFastSend(band, "enable", value);
          throttleFastSend(band, "f0", f.f0);
          throttleFastSend(band, "gain", f.gain);
          throttleFastSend(band, "Q", f.Q);
          throttleFastSend(band, "type", f.type);
        }
      }

      // ===== REALTIME =====
      if (field === "gain" || field === "Q" || field === "f0") {
        throttleFastSend(band, field, value);
      }

      if (field === "type") {
        throttleFastSend(band, field, value);
      }

      return copy;
    });
  };

  /* ================= ACTIVE FILTERS ================= */

  const activeFilters = useMemo(() => {
    if (!draft) return [];

    return draft.filters
      .map((f, i) => ({ ...f, band: i }))
      .filter((f) => f.enable);
  }, [draft]);

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  if (!draft) {
    return <div className="p-3 text-sm text-gray-400">Loading EQ...</div>;
  }

  /* ================= UI ================= */

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* ===== HEADER ===== */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          {/* POWER */}
          <button
            onClick={togglePower}
            disabled
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div
          className={`text-gray-500 transition-transform
            ${open ? "rotate-180" : ""}
          `}
        >
          ▾
        </div>
      </div>

      {/* ===== BODY ===== */}
      {open && (
        <div className={`p-3 space-y-3 ${!enable && "opacity-60"}`}>
          <div className="p-3 text-red-600 text-center text-sm w-full">
            Để thay đổi độ lớn +- của Pregain, dùng biến trở hay điều khiển qua
            App mobile. Hãy vào Cài đặt &gt; Pregain điều chỉnh
          </div>

          {/* Bảng giá trị hiện tại */}
          <div className="bg-gray-100 border rounded-xl p-3">
            <table className="min-w-full border-collapse border border-gray-300 text-center text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="border px-2 py-1">Tên Biến Trở / Preamp</th>
                  <th className="border px-2 py-1">Điều khiển bằng</th>
                  <th className="border px-2 py-1">Giá trị hiện tại</th>
                </tr>
              </thead>
              <tbody>
                <tr className="even:bg-gray-50">
                  <td className="border px-2 py-1">VOLUME</td>
                  <td className="border px-2 py-1">
                    {Pre_mode === 1 ? " ( Biến Trở )" : " (Key + APP)"}
                  </td>
                  <td className="border px-2 py-1">{Vr_log[0]}</td>
                </tr>

                <tr className="even:bg-gray-50">
                  <td className="border px-2 py-1">Bass F0</td>
                  <td className="border px-2 py-1">
                    {Pre_mode === 1 ? " ( Biến Trở )" : " (App)"}
                  </td>
                  <td className="border px-2 py-1">{Vr_log[1]}</td>
                </tr>

                <tr className="even:bg-gray-50">
                  <td className="border px-2 py-1">MID F1</td>
                  <td className="border px-2 py-1">
                    {Pre_mode === 1 ? " ( Biến Trở )" : " (App)"}
                  </td>
                  <td className="border px-2 py-1">{Vr_log[2]}</td>
                </tr>

                <tr className="even:bg-gray-50">
                  <td className="border px-2 py-1">Treble F2</td>
                  <td className="border px-2 py-1">
                    {Pre_mode === 1 ? " ( Biến Trở )" : " (App)"}
                  </td>
                  <td className="border px-2 py-1">{Vr_log[3]}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* ===== GRAPH ===== */}
          <div className="w-full bg-[#0f2a35] p-2 rounded-xl">
            <EQGraph
              filters={activeFilters}
              pregain={draft.pregain}
              onDrag={(band, v) => {
                if (v.f0 !== undefined) updateFilter(band, "f0", v.f0);

                if (v.gain !== undefined) updateFilter(band, "gain", v.gain);
              }}
            />
          </div>

          {/* ===== FILTER ENABLE ===== */}
          <div className="bg-gray-100 border rounded-xl p-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="text-xs font-semibold">Filters</div>

              {draft.filters.slice(0, 3).map((f, i) => (
                <button
                  key={i}
                  disabled
                  onClick={() => updateFilter(i, "enable", !f.enable)}
                  className={`px-2 py-1 text-xs rounded-lg border transition
                    ${f.enable ? "bg-blue-500 text-white" : "bg-gray-200"}
                  `}
                >
                  F{i}
                </button>
              ))}
            </div>
          </div>

          {/* ===== TABLE ===== */}
          <div className="border rounded-xl overflow-hidden text-sm bg-white">
            {/* HEADER */}
            <div className="grid grid-cols-[30px_60px_1fr_1fr_1fr] bg-gray-100  gap-x-1 px-4 py-3 text-center font-semibold text-gray-700">
              <div>Band</div>
              <div>Type</div>
              <div>Fc</div>
              <div>Gain</div>
              <div>Q</div>
            </div>

            {draft.filters
              .map((f, i) => ({ ...f, band: i }))
              .filter((f) => f.enable)
              .map((f, idx) => (
                <div
                  key={f.band}
                  className={`
                    grid grid-cols-[30px_60px_1fr_1fr_1fr]
                    items-center
                    gap-x-1
                    px-4 py-3
                    border-t
                    ${idx % 2 === 0 ? "bg-white" : "bg-gray-50"}
                  `}
                >
                  <div className="font-medium text-gray-700">F{f.band}</div>

                  <select
                    value={f.type}
                    onChange={(e) =>
                      updateFilter(f.band, "type", Number(e.target.value))
                    }
                    className="w-full bg-white border rounded-lg px-2 py-1 shadow-sm"
                  >
                    {EQ_FILTER_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>

                  <input
                    type="number"
                    value={f.f0}
                    onChange={(e) =>
                      updateFilter1(f.band, "f0", Number(e.target.value))
                    }
                    onBlur={() => {
                      const v = Math.max(20, Math.min(20000, f.f0));
                      updateFilter(f.band, "f0", v);
                    }}
                    className="w-full bg-white border rounded-lg px-2 py-1 shadow-sm text-right"
                  />

                  <input
                    type="number"
                    step={0.01}
                    value={f.gain.toFixed(2)}
                    disabled
                    className="w-full bg-gray-100 border rounded-lg px-2 py-1 text-right text-gray-600"
                  />

                  <input
                    type="number"
                    step={0.001}
                    value={f.Q.toFixed(3)}
                    onChange={(e) =>
                      updateFilter1(f.band, "Q", Number(e.target.value))
                    }
                    onBlur={(e) => {
                      updateFilter(f.band, "Q", Number(e.target.value));
                    }}
                    className="w-full bg-white border rounded-lg px-2 py-1 shadow-sm text-right"
                  />
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
