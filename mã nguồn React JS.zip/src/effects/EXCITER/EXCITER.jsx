import { useEffect, useState, useCallback } from "react";
import { useEXCITER } from "./useEXCITER";

export default function EXCITER({ index, name }) {
  const { data, load, setEnable, setCutoff, setDry, setWet } =
    useEXCITER(index);

  const [open, setOpen] = useState(false);

  const [local, setLocal] = useState({
    f_cut: 0,
    dry: 0,
    wet: 0,
  });

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) load();
  }, [data, load]);

  /* ================= SYNC ================= */
  useEffect(() => {
    if (!data) return;

    setLocal((prev) => {
      if (
        prev.f_cut === data.f_cut &&
        prev.dry === data.dry &&
        prev.wet === data.wet
      ) {
        return prev;
      }

      return {
        f_cut: data.f_cut ?? 0,
        dry: data.dry ?? 0,
        wet: data.wet ?? 0,
      };
    });
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      await setEnable(!enable);
    },
    [enable, setEnable],
  );

  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          <MobileRow
            label="Cutoff"
            value={local.f_cut}
            min={30}
            max={20000}
            unit="Hz"
            enable={enable}
            onChange={(v) => setCutoff(v)}
          />

          <MobileRow
            label="Dry"
            value={local.dry}
            min={0}
            max={100}
            unit="%"
            enable={enable}
            onChange={(v) => setDry(v)}
          />

          <MobileRow
            label="Wet"
            value={local.wet}
            min={0}
            max={100}
            unit="%"
            enable={enable}
            onChange={(v) => setWet(v)}
          />
        </div>
      )}
    </div>
  );
}

/* ================= MOBILE ROW ================= */
function MobileRow({ label, value, min, max, unit, enable, onChange }) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4 h-9">
      <div className="w-[120px] text-sm font-medium text-gray-700">{label}</div>

      <div className="flex items-center gap-2 h-9">
        <input
          type="text"
          inputMode="decimal"
          value={display}
          disabled={!enable}
          onChange={handleChange}
          onBlur={handleBlur}
          className="
            w-24 h-9
            px-3
            text-center text-sm
            rounded-lg
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400
          "
        />

        <span className="text-xs text-gray-500 w-8 text-left">
          {unit ?? ""}
        </span>
      </div>
    </div>
  );
}
