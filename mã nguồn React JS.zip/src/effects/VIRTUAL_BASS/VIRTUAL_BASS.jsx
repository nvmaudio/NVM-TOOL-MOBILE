import { useEffect, useState, useCallback } from "react";
import { useVIRTUAL_BASS } from "./useVIRTUAL_BASS";

export default function VIRTUAL_BASS({ index, name }) {
  const { data, loadVBedVB, setEnable, setFCut, setIntensity, setEnhanced } =
    useVIRTUAL_BASS(index === 0 ? null : index);

  const [open, setOpen] = useState(false);

  const [local, setLocal] = useState({
    f_cut: 0,
    intensity: 0,
    enhanced: 0,
  });

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadVBedVB();
  }, [data, loadVBedVB]);

  /* ================= SYNC ================= */
  useEffect(() => {
    if (!data) return;

    setLocal((prev) => {
      if (
        prev.f_cut === data.f_cut &&
        prev.intensity === data.intensity &&
        prev.enhanced === data.enhanced
      ) {
        return prev;
      }

      return {
        f_cut: data.f_cut ?? 0,
        intensity: data.intensity ?? 0,
        enhanced: data.enhanced ?? 0,
      };
    });
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      await setEnable(!enable);
    },
    [enable, setEnable],
  );

  /* ================= SAFE RETURN ================= */
  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          <MobileRow
            label="Cutoff"
            value={local.f_cut}
            min={30}
            max={300}
            unit="Hz"
            enable={enable}
            onChange={(v) => setFCut(v)}
          />

          <MobileRow
            label="Intensity"
            value={local.intensity}
            min={0}
            max={100}
            unit="%"
            enable={enable}
            onChange={(v) => setIntensity(v)}
          />

          <SwitchRow
            label="Enhanced"
            value={local.enhanced}
            enable={enable}
            onToggle={(v) => setEnhanced(v)}
          />
        </div>
      )}
    </div>
  );
}

/* ================= MOBILE INPUT ================= */
function MobileRow({ label, value, min, max, unit, enable, onChange }) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4">
      <div className="pl-2 text-sm font-medium">{label}</div>

      <div className="flex items-center gap-2">
        <input
          type="text"
          inputMode="decimal"
          value={display}
          disabled={!enable}
          onChange={handleChange}
          onBlur={handleBlur}
          className="
            w-24 px-3 py-2 text-center rounded-lg text-sm
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400
          "
        />

        {unit ? (
          <span className="text-xs text-gray-500 w-8 text-left">{unit}</span>
        ) : (
          <span className="text-xs text-gray-500 w-8 text-left"></span>
        )}
      </div>
    </div>
  );
}

/* ================= SWITCH ================= */
function SwitchRow({ label, value, enable, onToggle }) {
  return (
    <div className="flex items-center justify-between gap-4 h-9">
      <div className="pl-2 text-sm font-medium">{label}</div>

      <div className="flex items-center gap-2 h-9">
        <div className="w-24">
          <button
            disabled={!enable}
            onClick={() => onToggle(value ? 0 : 1)}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${value ? "bg-blue-500" : "bg-gray-300"}
          `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${value ? "translate-x-4" : "translate-x-1"}
            `}
            />
          </button>
        </div>

        <span className="text-xs text-gray-500 w-8"></span>
      </div>
    </div>
  );
}
