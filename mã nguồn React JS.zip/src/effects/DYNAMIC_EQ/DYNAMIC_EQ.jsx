import { useEffect, useState, useCallback } from "react";
import { useDYNAMIC_EQ } from "./useDYNAMIC_EQ";
import { useEQ } from "./../EQ/useEQ";

export default function DYNAMIC_EQ({ index, name }) {
  const {
    data,
    loadDynamicEQ,
    setEnable,
    setLow,
    setNormal,
    setHigh,
    setAttack,
    setRelease,
  } = useDYNAMIC_EQ(index);

  const { data: data2, loadEQ: loadEQ2 } = useEQ(index - 2);
  const { data: data1, loadEQ: loadEQ1 } = useEQ(index - 1);

  const [local, setLocal] = useState({
    low: 0,
    normal: 0,
    high: 0,
    attack: 0,
    release: 0,
  });

  const [open, setOpen] = useState(false);

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadDynamicEQ();
  }, [data, loadDynamicEQ]);

  useEffect(() => {
    if (!data1) loadEQ1();
    if (!data2) loadEQ2();
  }, [data1, data2, loadEQ1, loadEQ2]);

  /* ================= SYNC (ANTI GIẬT) ================= */
  useEffect(() => {
    if (!data) return;

    setLocal((prev) => {
      if (
        prev.low === data.low &&
        prev.normal === data.normal &&
        prev.high === data.high &&
        prev.attack === data.attack &&
        prev.release === data.release
      ) {
        return prev;
      }

      return {
        low: data.low ?? 0,
        normal: data.normal ?? 0,
        high: data.high ?? 0,
        attack: data.attack ?? 0,
        release: data.release ?? 0,
      };
    });
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();

      if (!enable) {
        if (!data1 || !data2) {
          alert("Chưa load xong EQ");
          return;
        }

        if (!data1.enable || !data2.enable) {
          alert("Phải bật 2 EQ phía trên trước");
          return;
        }
      }

      await setEnable(!enable);
    },
    [enable, data1, data2, setEnable],
  );

  /* ================= UPDATE ================= */
  const update = (key, v) => {
    if (v === undefined || v === null || isNaN(v)) return;

    setLocal((prev) => ({ ...prev, [key]: v }));

    switch (key) {
      case "low":
        setLow(v);
        break;
      case "normal":
        setNormal(v);
        break;
      case "high":
        setHigh(v);
        break;
      case "attack":
        setAttack(v);
        break;
      case "release":
        setRelease(v);
        break;
      default:
        break;
    }
  };

  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          <MobileRow
            label="Low Threshold"
            value={local.low / 100}
            min={-90}
            max={0}
            step={0.1}
            unit="dB"
            enable={enable}
            onChange={(v) => update("low", Math.round(v * 100))}
          />

          <MobileRow
            label="Normal Threshold"
            value={local.normal / 100}
            min={-90}
            max={0}
            step={0.1}
            unit="dB"
            enable={enable}
            onChange={(v) => update("normal", Math.round(v * 100))}
          />

          <MobileRow
            label="High Threshold"
            value={local.high / 100}
            min={-90}
            max={0}
            step={0.1}
            unit="dB"
            enable={enable}
            onChange={(v) => update("high", Math.round(v * 100))}
          />

          <MobileRow
            label="Attack"
            value={local.attack}
            min={0}
            max={2000}
            step={1}
            unit="ms"
            enable={enable}
            onChange={(v) => update("attack", v)}
          />

          <MobileRow
            label="Release"
            value={local.release}
            min={0}
            max={2000}
            step={1}
            unit="ms"
            enable={enable}
            onChange={(v) => update("release", v)}
          />
        </div>
      )}
    </div>
  );
}

/* ================= MOBILE INPUT ================= */
function MobileRow({ label, value, min, max, unit, enable, onChange }) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép: "", "-", "-12", "-12.3"
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4 ">
      <div className="pl-2 text-sm font-medium">{label}</div>

      <div className="flex items-center gap-2">
        <input
          type="text"
          value={display}
          disabled={!enable}
          onChange={handleChange}
          onBlur={handleBlur}
          className="
            w-24 px-3 py-2 text-center rounded-lg text-sm
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400"
        />
        <span className="text-xs text-gray-500 w-8">{unit}</span>
      </div>
    </div>
  );
}
