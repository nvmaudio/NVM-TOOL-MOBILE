import { useEffect, useState, useCallback } from "react";
import { useCOMPANDER } from "./useCOMPANDER";

export default function Compander({ index, name }) {
  const {
    data,
    loadCOMPANDER,
    setCOMPANDEREnable,
    setThreshold,
    setSlopeBelow,
    setSlopeAbove,
    setAttack,
    setRelease,
    setPregain,
  } = useCOMPANDER(index);

  const [open, setOpen] = useState(false);

  const [local, setLocal] = useState({
    threshold: 0,
    slope_below: 0,
    slope_above: 0,
    pregain: 0,
    alpha_attack: 0,
    alpha_release: 0,
  });

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadCOMPANDER();
  }, [data, loadCOMPANDER]);

  /* ================= SYNC (ANTI GIẬT) ================= */
  useEffect(() => {
    if (!data) return;

    setLocal((prev) => {
      if (
        prev.threshold === data.threshold &&
        prev.slope_below === data.slope_below &&
        prev.slope_above === data.slope_above &&
        prev.pregain === data.pregain &&
        prev.alpha_attack === data.alpha_attack &&
        prev.alpha_release === data.alpha_release
      ) {
        return prev;
      }

      return {
        threshold: data.threshold ?? 0,
        slope_below: data.slope_below ?? 0,
        slope_above: data.slope_above ?? 0,
        pregain: data.pregain ?? 0,
        alpha_attack: data.alpha_attack ?? 0,
        alpha_release: data.alpha_release ?? 0,
      };
    });
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();
      await setCOMPANDEREnable(!enable);
    },
    [enable, setCOMPANDEREnable],
  );

  /* ================= UPDATE ================= */
  const update = (key, v) => {
    if (v === undefined || v === null || isNaN(v)) return;

    switch (key) {
      case "threshold":
        setThreshold(Math.round(v * 100));
        break;
      case "slope_below":
        setSlopeBelow(Math.round(v * 100));
        break;
      case "slope_above":
        setSlopeAbove(Math.round(v * 100));
        break;
      case "pregain":
        setPregain(Math.round(v * 100));
        break;
      case "alpha_attack":
        setAttack(v);
        break;
      case "alpha_release":
        setRelease(v);
        break;
      default:
        break;
    }
  };

  if (!data) {
    return <div className="p-4 text-sm text-gray-400">Loading {name}</div>;
  }
  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`text-gray-500 transition ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className={`p-4 space-y-4 ${!enable && "opacity-50"}`}>
          <MobileRow
            label="Threshold"
            value={local.threshold / 100}
            min={-90}
            max={0}
            step={0.1}
            unit="dB"
            enable={enable}
            onChange={(v) => update("threshold", v)}
          />

          <MobileRow
            label="Ratio Below"
            value={local.slope_below / 100}
            min={0.1}
            max={10}
            step={0.1}
            enable={enable}
            onChange={(v) => update("slope_below", v)}
          />

          <MobileRow
            label="Ratio Above"
            value={local.slope_above / 100}
            min={0.1}
            max={10}
            step={0.1}
            enable={enable}
            onChange={(v) => update("slope_above", v)}
          />

          <MobileRow
            label="Pregain"
            value={local.pregain / 100}
            min={-72}
            max={18}
            step={0.1}
            unit="dB"
            enable={enable}
            onChange={(v) => update("pregain", v)}
          />

          <MobileRow
            label="Attack"
            value={local.alpha_attack}
            min={0}
            max={32767}
            unit="ms"
            enable={enable}
            onChange={(v) => update("alpha_attack", v)}
          />

          <MobileRow
            label="Release"
            value={local.alpha_release}
            min={0}
            max={32767}
            unit="ms"
            enable={enable}
            onChange={(v) => update("alpha_release", v)}
          />
        </div>
      )}
    </div>
  );
}

/* ================= MOBILE INPUT ================= */
function MobileRow({ label, value, min, max, unit, enable, onChange }) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center justify-between gap-4">
      <div className="pl-2 text-sm font-medium">{label}</div>

      <div className="flex items-center gap-2">
        <input
          type="text"
          inputMode="decimal"
          value={display}
          disabled={!enable}
          onChange={handleChange}
          onBlur={handleBlur}
          className="
            w-24 px-3 py-2 text-center rounded-lg text-sm
            bg-white border border-gray-300
            focus:outline-none focus:ring-2 focus:ring-green-400"
        />
        {unit ? (
          <span className="text-xs text-gray-500 w-8 text-left">{unit}</span>
        ) : (
          <span className="text-xs text-gray-500 w-8 text-left"></span>
        )}
      </div>
    </div>
  );
}
