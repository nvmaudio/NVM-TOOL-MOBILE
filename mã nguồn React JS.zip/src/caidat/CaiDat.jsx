import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Settings, Volume2, Bluetooth, Bell, Key, Speaker } from "lucide-react";

import TabVolume from "./tabs/TabVolume";
import TabBluetooth from "./tabs/TabBluetooth";
import TabKey from "./tabs/TabKey";
import TabParameter from "./tabs/TabParameter";
import TabPreamp from "./tabs/TabPreamp";
import TabSystem from "./tabs/TabSystem";
import TabThongBao from "./tabs/TabThongBao";

//import TabRemid, { FlashModal } from "./tabs/Remid";

import { useSystemConfig } from "@hooks/useSystemConfig";

const menus = [
  { id: "system", label: "CĐ Nhanh", icon: Settings, color: "text-blue-500" },
  { id: "system1", label: "Tham số", icon: Settings, color: "text-orange-500" },
  { id: "volume", label: "Âm lượng", icon: Volume2, color: "text-emerald-500" },
  {
    id: "bluetooth",
    label: "Bluetooth",
    icon: Bluetooth,
    color: "text-indigo-500",
  },
  { id: "thongbao", label: "Thông báo", icon: Bell, color: "text-yellow-500" },
  { id: "key", label: "Phím", icon: Key, color: "text-pink-500" },
  { id: "preamp", label: "Preamp", icon: Speaker, color: "text-teal-500" },
];

const tabMap = {
  system: TabSystem,
  system1: TabParameter,
  volume: TabVolume,
  bluetooth: TabBluetooth,
  thongbao: TabThongBao,
  //  remid: TabRemid,
  key: TabKey,
  preamp: TabPreamp,
};

export default function CaiDatMenuMobile() {
  const { loadData, onData, pushVrLog } = useSystemConfig();
  const nav = useNavigate();
  const [activeMenu, setActiveMenu] = useState("system");

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    const off = onData((packet) => {
      if (packet.cmd === 200) {
        pushVrLog(packet.data);
      }
    });
    return off;
  }, [onData, pushVrLog]);

  const DefaultTab = () => <p>Tab chưa có</p>;

  const ActiveTab = useMemo(() => {
    return tabMap[activeMenu] || DefaultTab;
  }, [activeMenu]);

  return (
    <div className="w-screen h-screen flex flex-col bg-slate-200">
      {/* HEADER */}
      <div className="h-[50px] flex items-center justify-between px-4 bg-white shadow shrink-0">
        <h1 className="text-base font-semibold">Cài đặt</h1>
        <button
          onClick={() => nav("/")}
          className="text-sm px-3 py-1 bg-gray-500 text-white rounded-lg"
        >
          Quay lại
        </button>
      </div>

      {/* CONTENT */}

      <div className="flex-1 min-h-0 p-3 bg-slate-200 overflow-hidden">
        <ActiveTab />
      </div>

      {/* BOTTOM TAB BAR */}
      <div className="h-[64px] bg-white border-t flex shrink-0">
        {menus.map((menu) => {
          const Icon = menu.icon;
          const isActive = activeMenu === menu.id;

          return (
            <button
              key={menu.id}
              onClick={() => setActiveMenu(menu.id)}
              className={`flex flex-col items-center justify-center flex-1 text-xs transition active:scale-95
                ${isActive && "bg-blue-200"}
              `}
            >
              <Icon
                size={20}
                className={`transition ${
                  isActive ? "text-blue-600" : menu.color
                }`}
              />

              <span
                className={`mt-1 text-[10px] transition ${
                  isActive ? "text-blue-600 font-medium" : "text-gray-500"
                }`}
              >
                {menu.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
