import { useState } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";

const PROFILES = [
  { value: 0, label: "Tai nghe (Headset)" },
  { value: 1, label: "Thiết bị rảnh tay (Handsfree)" },
  { value: 2, label: "Loa ngoài (Loudspeaker)" },
  { value: 3, label: "Tai nghe (Headphones)" },
  { value: 4, label: "Hệ thống âm thanh Hi-Fi (Hi-Fi Audio)" },
];

const A2dp_AAC = [
  { value: 0, label: "SBC" },
  { value: 1, label: "AAC + SBC" },
];

export default function TabBluetooth() {
  const { data, update, save } = useSystemConfig();
  const [saving, setSaving] = useState(false);

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const handleSave = async () => {
    setSaving(true);
    await save();
    setSaving(false);
  };

  const selectClass =
    "w-full h-8 px-3 border border-gray-500 rounded-xl bg-white text-sm text-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-sm hover:shadow-md transition";

  const selectClassBlue =
    "w-full h-8 px-3 border border-blue-300 rounded-xl bg-white text-sm text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-sm hover:shadow-md transition";

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl overflow-hidden text-[12px]">
      <div className="sticky top-0 z-10 bg-white px-4 py-3 shadow-sm">
        <h1 className="text-[17px] font-bold tracking-tight text-black">
          Cấu hình Bluetooth
        </h1>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto px-3 py-2 space-y-2 text-black">
        {/* Tên Bluetooth */}
        <FormRow label="Tên Bluetooth">
          <input
            type="text"
            value={data.BT_Name}
            onChange={(e) => update("BT_Name", e.target.value)}
            className={selectClassBlue}
            maxLength={40}
            title="Tên Bluetooth (tối đa 40 ký tự)"
          />
        </FormRow>

        {/* Profile */}
        <FormRow label="Profile BT">
          <select
            value={data.Profile_BT}
            onChange={(e) => update("Profile_BT", Number(e.target.value))}
            className={selectClass}
            title="Chọn profile Bluetooth"
          >
            {PROFILES.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </FormRow>

        {/* A2DP AAC */}
        <FormRow label="Định dạng âm thanh">
          <select
            value={data.A2dp_AAC}
            onChange={(e) => update("A2dp_AAC", Number(e.target.value))}
            className={selectClass}
            title="Chọn định dạng âm thanh"
          >
            {A2dp_AAC.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </FormRow>

        {/* Background type */}
        <Row
          title="Chạy nền BT"
          subtitle="Khi kết nối tự chuyển về mode Bluetooth"
        >
          <IOSSwitch
            checked={data.Bt_BackgroundType === 1}
            onChange={(v) => update("Bt_BackgroundType", v ? 1 : 0)}
          />
        </Row>

        {/* Simple pairing */}
        <Row
          title="Yêu cầu mật khẩu khi kết nối"
          subtitle="Khi kết nối sẽ cần nhập mật khẩu này"
        >
          <IOSSwitch
            checked={data.Bt_SimplePairingEnable === 0}
            onChange={(v) => update("Bt_SimplePairingEnable", v ? 0 : 1)}
          />
        </Row>

        {/* PIN Code */}
        <FormRow label="Mã PIN Bluetooth">
          <input
            type="text"
            value={data.Bt_PinCode}
            onChange={(e) => update("Bt_PinCode", e.target.value)}
            maxLength={4}
            className={selectClass}
            title="Mã PIN Bluetooth (tối đa 4 ký tự),  BLE luôn cần"
          />
        </FormRow>
      </div>

      {/* Save Button */}
      <div className="sticky bottom-0 bg-white p-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <button
          onClick={handleSave}
          disabled={saving}
          className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-medium text-white transition ${
            saving
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 active:scale-95"
          }`}
        >
          {saving && (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
          )}
          {saving ? "Đang lưu..." : "Lưu cấu hình"}
        </button>
      </div>
    </div>
  );
}

function Row({ title, subtitle, children, isLast }) {
  return (
    <div
      className={`flex items-center justify-between px-4 py-4 ${
        !isLast ? "border-b border-[#E5E5EA]" : ""
      }`}
    >
      <div className="max-w-[70%]">
        <div className="text-[14px] text-black">{title}</div>
        {subtitle && (
          <div className="text-[12px] text-[#8E8E93] mt-1 leading-snug">
            {subtitle}
          </div>
        )}
      </div>
      {children}
    </div>
  );
}

function IOSSwitch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition ${
        checked ? "bg-[#34C759]" : "bg-[#E5E5EA]"
      } ${disabled ? "opacity-40" : ""}`}
    >
      <span
        className={`inline-block h-6 w-6 transform rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}

/* ================= ROW ================= */
function FormRow({ label, children }) {
  return (
    <div className="grid grid-cols-1 items-center gap-2 px-3 py-1 md:grid-cols-2">
      <div className="font-medium text-gray-700">{label}</div>
      <div className="flex justify-start">{children}</div>
    </div>
  );
}
