import { useState } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";

const AUDIO_MODES = [
  { value: 0, label: "2.0 Stereo" },
  { value: 1, label: "2.1 Sub" },
  { value: 2, label: "Mono" },
  { value: 3, label: "1.1" },
  { value: 4, label: "3 Way" },
];

const DEFAULT_MODES = [
  { value: 1, label: "Bluetooth" },
  { value: 2, label: "AUX" },
];

export default function TabBluetooth() {
  const { data, update, save } = useSystemConfig();
  const [saving, setSaving] = useState(false);

  if (!data) {
    return (
      <div className="flex h-full items-center justify-center text-gray-500">
        Loading...
      </div>
    );
  }

  const {
    Delay_start,
    Audio_mode,
    Nho_mode,
    Mode_mac_dinh,
    Nho_mode_effect,
    I2s1_en,
  } = data;

  const handleSave = async () => {
    try {
      setSaving(true);
      await save();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl overflow-hidden text-[12px]">
      {/* HEADER */}
      <div className="sticky top-0 z-10 bg-white px-4 py-3 shadow-sm">
        <h2 className="text-[17px] font-semibold text-black">
          Cấu hình hệ thống
        </h2>
      </div>

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-2">
        <div className="divide-y divide-gray-200 bg-white">
          {/* Delay */}
          <Row label="Delay bật nguồn">
            <select
              value={Delay_start}
              onChange={(e) => update("Delay_start", Number(e.target.value))}
              className="h-9 rounded-lg border border-gray-300 px-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              {Array.from({ length: 51 }, (_, i) => (
                <option key={i} value={i}>
                  {i * 100} ms
                </option>
              ))}
            </select>
          </Row>

          {/* Audio Mode */}
          <Row label="Audio Mode">
            <select
              value={Audio_mode}
              disabled
              className="h-9 rounded-lg border border-gray-200 bg-gray-100 px-2 text-gray-400"
            >
              {AUDIO_MODES.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </Row>

          {/* Nhớ mode */}
          <Row label="Nhớ mode BT/AUX">
            <Switch
              checked={Nho_mode === 1}
              onChange={(v) => update("Nho_mode", v ? 1 : 0)}
            />
          </Row>

          {/* Mode mặc định */}
          <Row label="Mode mặc định">
            <select
              value={Mode_mac_dinh}
              disabled={Nho_mode === 1}
              onChange={(e) => update("Mode_mac_dinh", Number(e.target.value))}
              className={`h-9 rounded-lg px-2 ${
                Nho_mode === 1
                  ? "border border-gray-200 bg-gray-100 text-black"
                  : "border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              }`}
            >
              {DEFAULT_MODES.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </Row>

          {/* Nhớ effect */}
          <Row label="Nhớ Effect">
            <Switch
              checked={Nho_mode_effect === 1}
              onChange={(v) => update("Nho_mode_effect", v ? 1 : 0)}
            />
          </Row>

          {/* I2S */}
          <Row label="I2S 1 ON">
            <Switch
              checked={I2s1_en === 1}
              onChange={(v) => update("I2s1_en", v ? 1 : 0)}
            />
          </Row>
        </div>
      </div>

      {/* SAVE BUTTON */}
      <div className="sticky bottom-0 bg-white p-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <button
          onClick={handleSave}
          disabled={saving}
          className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-medium text-white transition ${
            saving
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 active:scale-95"
          }`}
        >
          {saving && (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
          )}
          {saving ? "Đang lưu..." : "Lưu cấu hình"}
        </button>
      </div>
    </div>
  );
}

/* ================= ROW ================= */

function Row({ label, children }) {
  return (
    <div className="flex items-center justify-between p-3">
      <div className="text-black text-[14px]">{label}</div>
      <div>{children}</div>
    </div>
  );
}

/* ================= SWITCH ================= */

function Switch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative h-6 w-11 rounded-full transition ${
        checked ? "bg-blue-600" : "bg-gray-300"
      } ${disabled ? "opacity-50" : ""}`}
    >
      <div
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? "translate-x-5" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}
