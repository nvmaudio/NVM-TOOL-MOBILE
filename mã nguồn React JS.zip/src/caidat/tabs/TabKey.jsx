import { useState } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";

const selectKey = [
  { value: "0", text: "NONE" },
  { value: "1", text: "PLAY_PAUSE" },
  { value: "2", text: "PRE" },
  { value: "3", text: "NEXT" },
  { value: "4", text: "MUSIC_VOLUP" },
  { value: "5", text: "MUSIC_VOLDOWN" },
  { value: "6", text: "3D" },
  { value: "7", text: "VB_DAC0" },
  { value: "8", text: "VB_Classic_DAC0" },
  { value: "9", text: "VB_DACX" },
  { value: "10", text: "VB_Classic_DACX" },
  { value: "11", text: "EFFECTMODE" },
  { value: "12", text: "MODE" },
  { value: "13", text: "BT_PAIRING" },
  { value: "14", text: "BT_PAIRING_CLEAR_DATA" },
  { value: "15", text: "BT_CLEAR_BT_LIST" },
  { value: "16", text: "BT_TWS_PAIRING" },
  { value: "17", text: "BT_TWS_CLEAR_LIST" },
  { value: "18", text: "MUTE_ON_OFF" },
];

// Chỉ lấy những row cần hiển thị
const Item_index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

export default function TabKey() {
  const { data, update, save } = useSystemConfig();
  const [saving, setSaving] = useState(false);

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const { Key_matrix, Key_en } = data;

  // Update trực tiếp Key_matrix
  const updateItem = (rowIndex, colIndex, value) => {
    update("Key_matrix", (prev) =>
      prev.map((row, ri) =>
        ri === rowIndex
          ? row.map((col, ci) => (ci === colIndex ? Number(value) : col))
          : row,
      ),
    );
  };

  const resetDefault = () => {
    const newMatrix = [
      [0, 12, 16, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 11, 7, 0, 0],
      [0, 2, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 3, 0, 0, 0],
      [0, 1, 14, 0, 0],
    ];
    update("Key_matrix", newMatrix);
  };

  const resetDefaultWithVol = () => {
    const newMatrix = [
      [0, 12, 16, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 11, 7, 0, 0],
      [0, 2, 5, 5, 5],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 3, 4, 4, 4],
      [0, 1, 14, 0, 0],
    ];
    update("Key_matrix", newMatrix);
  };

  const handleSave = async () => {
    setSaving(true);
    await save();
    setSaving(false);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl overflow-hidden text-[12px]">
      <div className="sticky top-0 z-10 bg-white px-4 py-3 shadow-sm">
        <h1 className="text-[17px] font-bold tracking-tight text-black">
          Cấu hình Phím Bấm
        </h1>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto px-3 py-2 space-y-2 text-black">
        {/* Scrollable content */}

        {/* Bật/Tắt Key */}

        <Row title="Bật Phím Bấm" subtitle="Chỉ thay đổi được ở Cài đặt nhanh!">
          <IOSSwitch
            checked={Key_en === 1}
            onChange={(v) => update("Key_en", v ? 1 : 0)}
            disabled
          />
        </Row>

        {/* Table Key */}
        <div className="flex-1 min-h-0 overflow-y-auto px-3 py-2 space-y-2 text-black">
          <table className="min-w-[700px] border-collapse border border-gray-300 text-center text-[14px]">
            <thead className="bg-gray-100">
              <tr>
                <th className="border px-2 py-1">Số Key</th>
                <th className="border px-2 py-1">Nhấn Nhả</th>
                <th className="border px-2 py-1">Nhấn giữ</th>
                <th className="border px-2 py-1">Vẫn giữ</th>
                <th className="border px-2 py-1">Nhả giữ</th>
              </tr>
            </thead>
            <tbody>
              {Item_index.map((rowIndex, keyIdx) => {
                const row = Key_matrix[rowIndex] || [];
                return (
                  <tr
                    key={rowIndex}
                    className="transition even:bg-gray-50 hover:bg-gray-100"
                  >
                    <td className="border px-2 py-1">{`Key ${keyIdx + 1}`}</td>
                    {row.slice(1).map((col, ci) => (
                      <td key={ci} className="border px-2 py-1">
                        <select
                          value={col}
                          onChange={(e) =>
                            updateItem(rowIndex, ci + 1, e.target.value)
                          }
                          disabled={Key_en === 0}
                          className="w-full rounded border px-1 py-0.5 text-sm focus:outline-none focus:ring-1 focus:ring-blue-400"
                          style={{ color: col === 0 ? "black" : "#0033cc" }}
                        >
                          {selectKey.map((opt) => (
                            <option key={opt.value} value={opt.value}>
                              {opt.text}
                            </option>
                          ))}
                        </select>
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Buttons */}
      <div className="sticky bottom-0 bg-white p-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)] flex justify-end gap-2">
        <button
          onClick={handleSave}
          disabled={saving}
          className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-medium text-white transition ${
            saving
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 active:scale-95"
          }`}
        >
          {saving && (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
          )}
          {saving ? "Đang lưu..." : "Lưu cấu hình"}
        </button>
        <button
          onClick={resetDefault}
          className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
        >
          Reset
        </button>
        <button
          onClick={resetDefaultWithVol}
          className="rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700"
        >
          Reset (VOLUP/VOLDOWN)
        </button>
      </div>
    </div>
  );
}

/* ================= SWITCH ================= */
function Switch({ checked, onChange, disabled, title }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`flex h-5 w-10 items-center rounded-full p-0.5 transition ${
        checked ? "bg-blue-600" : "bg-slate-300"
      } ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
      title={title}
    >
      <div
        className={`h-4 w-4 rounded-full bg-white shadow transition-transform ${
          checked ? "translate-x-5" : ""
        }`}
      />
    </button>
  );
}

function Row({ title, subtitle, children, isLast }) {
  return (
    <div
      className={`flex items-center justify-between px-4 py-4 ${
        !isLast ? "border-b border-[#E5E5EA]" : ""
      }`}
    >
      <div className="max-w-[70%]">
        <div className="text-[14px] text-black">{title}</div>
        {subtitle && (
          <div className="text-[12px] text-[#8E8E93] mt-1 leading-snug">
            {subtitle}
          </div>
        )}
      </div>
      {children}
    </div>
  );
}

function IOSSwitch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition ${
        checked ? "bg-[#34C759]" : "bg-[#E5E5EA]"
      } ${disabled ? "opacity-40" : ""}`}
    >
      <span
        className={`inline-block h-6 w-6 transform rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}
