import { Music2, Zap, Sliders, CheckCircle2 } from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";

export default function TabSystem() {
  const { data, update, save } = useSystemConfig();
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);

  /* ======================= DATA ======================= */

  const AUDIO_MODES = useMemo(
    () => [
      { value: 0, title: "2.0 Stereo", note: "Loa trái và phải R/L" },
      { value: 1, title: "2.1 Subwoofer", note: "L + R + Sub" },
      { value: 2, title: "Mono", note: "2 loa cùng tín hiệu R = L" },
      { value: 3, title: "1.1", note: "Mono EQ riêng R / L" },
      { value: 4, title: "3 Way", note: "EQ riêng R / L / Sub" },
    ],
    [],
  );

  const PREAMP_MODES = useMemo(
    () => [
      { value: 0, title: "App", note: "Điều chỉnh bằng Mobile App" },
      { value: 1, title: "VR", note: "Điều chỉnh bằng biến trở" },
    ],
    [],
  );

  const steps = useMemo(
    () => [
      { id: 1, label: "Audio", icon: Music2 },
      { id: 2, label: "Phím", icon: Zap },
      { id: 3, label: "Biến trở", icon: Zap },
      { id: 4, label: "Preamp", icon: Sliders },
      { id: 5, label: "Hoàn tất", icon: CheckCircle2 },
    ],
    [],
  );

  if (!data) return <div className="p-4">Loading...</div>;

  /* ======================= HELPERS ======================= */

  const currentStep = steps.find((s) => s.id === step);

  const getAudioMode = () =>
    AUDIO_MODES.find((x) => x.value === data.Audio_mode);

  const getPreampMode = () =>
    PREAMP_MODES.find((x) => x.value === data.Pre_mode);

  const canNext = useMemo(() => {
    if (step === 1) return data.Audio_mode !== undefined;
    if (step === 4 && data.Pre_en === 1) return data.Pre_mode !== undefined;
    return true;
  }, [step, data]);

  const next = () => setStep((s) => Math.min(s + 1, steps.length));

  const back = () => setStep((s) => Math.max(s - 1, 1));

  const finish = async () => {
    try {
      setSaving(true);

      if (data.Vr_en === 1) {
        await update("Dongbo_volume", 0);
        await update("Nho_volume", 0);
      } else {
        await update("Pre_mode", 0);
      }

      if (data.Key_en === 0) {
        await update("Nho_volume", 0);
      }

      await save();
      setStep(1);
    } finally {
      setSaving(false);
    }
  };

  /* Scroll top khi đổi step */
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [step]);

  /* ======================= UI ======================= */

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl overflow-hidden text-[13px]">
      {/* ===== HEADER ===== */}
      <div className="sticky top-0 z-10 bg-white px-4 py-3 pb-5">
        <div className="text-base font-semibold text-gray-800">
          <span className="font-medium text-gray-600">
            Bước {step}/{steps.length}
          </span>
          <span className="text-gray-500"> {currentStep?.label}</span>
        </div>

        <div className="mt-3 h-2 w-full rounded-full bg-gray-200">
          <div
            className="h-2 rounded-full bg-blue-600 transition-all duration-300"
            style={{ width: `${(step / steps.length) * 100}%` }}
          />
        </div>
      </div>

      {/* ===== CONTENT ===== */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-2">
        {/* STEP 1 */}
        {step === 1 && (
          <>
            <h2 className="text-lg font-semibold">Chọn chế độ âm thanh</h2>

            {AUDIO_MODES.map((m) => {
              const active = data.Audio_mode === m.value;

              return (
                <button
                  key={m.value}
                  onClick={() => update("Audio_mode", m.value)}
                  className={`w-full rounded-2xl border p-4 text-left transition ${
                    active
                      ? "border-blue-600 bg-blue-600 text-white"
                      : "bg-white"
                  }`}
                >
                  <div className="font-medium">{m.title}</div>
                  <div
                    className={`text-sm ${
                      active ? "text-blue-100" : "text-gray-500"
                    }`}
                  >
                    {m.note}
                  </div>
                </button>
              );
            })}
          </>
        )}

        {/* STEP 2 */}
        {step === 2 && (
          <>
            <h2 className="text-lg font-semibold">Phím bấm vật lý</h2>

            <ToggleCard
              active={data.Key_en}
              onClick={() => update("Key_en", data.Key_en ? 0 : 1)}
              color="purple"
              title="Bật / Tắt Phím"
              note="Điều khiển bằng nút cứng"
            />
          </>
        )}

        {/* STEP 3 */}
        {step === 3 && (
          <>
            <h2 className="text-lg font-semibold">Cấu hình Biến trở</h2>
            <ToggleCard
              active={data.Vr_en}
              onClick={() => update("Vr_en", data.Vr_en ? 0 : 1)}
              color="purple"
              title="Bật / Tắt VR"
              note="Điều chỉnh volume,.. bằng biến trở"
            />
          </>
        )}

        {/* STEP 4 */}
        {step === 4 && (
          <>
            <h2 className="text-lg font-semibold">EQ / Preamp</h2>

            <ToggleCard
              active={data.Pre_en}
              onClick={() => update("Pre_en", data.Pre_en ? 0 : 1)}
              color="purple"
              title="Bật Preamp"
              note="Bass / Mid / Treble"
            />

            {data.Pre_en === 1 &&
              PREAMP_MODES.map((m) => {
                const active = data.Pre_mode === m.value;

                return (
                  <button
                    key={m.value}
                    onClick={() => update("Pre_mode", m.value)}
                    className={`w-full rounded-xl border p-4 text-left transition ${
                      active
                        ? "border-purple-600 bg-purple-600 text-white"
                        : "bg-white"
                    }`}
                  >
                    <div className="font-medium">{m.title}</div>
                    <div
                      className={`text-xs ${
                        active ? "text-purple-100" : "text-gray-500"
                      }`}
                    >
                      {m.note}
                    </div>
                  </button>
                );
              })}
          </>
        )}

        {/* STEP 5 */}
        {step === 5 && (
          <>
            <h2 className="text-lg font-semibold">Xác nhận cấu hình</h2>

            <div className="rounded-2xl border bg-white p-4 text-base space-y-3">
              <SummaryRow label="Audio" value={getAudioMode()?.title} />
              <SummaryRow label="Phím" value={data.Key_en ? "Có" : "Không"} />
              <SummaryRow label="Preamp" value={data.Pre_en ? "Có" : "Không"} />
              {data.Pre_en === 1 && (
                <SummaryRow
                  label="Kiểu điều chỉnh"
                  value={getPreampMode()?.title}
                />
              )}
            </div>
          </>
        )}
      </div>

      {/* ===== BOTTOM NAV ===== */}
      <div className="sticky top-0 z-20 bg-white px-4 p-3 flex justify-between">
        {step > 1 ? (
          <button onClick={back} className="px-4 py-2 rounded-xl border">
            Quay lại
          </button>
        ) : (
          <div />
        )}

        {step < steps.length ? (
          <button
            disabled={!canNext}
            onClick={next}
            className={`px-5 py-2 rounded-xl text-white ${
              canNext ? "bg-blue-600" : "bg-gray-400 cursor-not-allowed"
            }`}
          >
            Tiếp theo
          </button>
        ) : (
          <button
            onClick={finish}
            disabled={saving}
            className={`px-5 py-2 rounded-xl text-white flex items-center gap-2 ${
              saving ? "bg-gray-400 cursor-not-allowed" : "bg-emerald-600"
            }`}
          >
            {saving && (
              <span className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            )}
            {saving ? "Đang lưu..." : "Hoàn tất"}
          </button>
        )}
      </div>
    </div>
  );
}

/* ================= COMPONENTS ================= */

function ToggleCard({ active, onClick, title, note, color }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 transition ${
        active ? `bg-${color}-50 border-${color}-500` : "bg-white"
      }`}
    >
      <div className="flex flex-col justify-center text-left">
        <div className="font-medium leading-tight pb-1">{title}</div>
        <div className="text-xs text-gray-500 leading-tight">{note}</div>
      </div>

      <div
        className={`relative h-6 w-11 rounded-full transition ${
          active ? `bg-${color}-500` : "bg-gray-300"
        }`}
      >
        <div
          className={`absolute top-1 left-1 h-4 w-4 rounded-full bg-white transition-transform ${
            active ? "translate-x-5" : ""
          }`}
        />
      </div>
    </button>
  );
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex justify-between">
      <span>{label}</span>
      <span className="font-medium">{value || "-"}</span>
    </div>
  );
}

function Row({ title, subtitle, children, isLast }) {
  return (
    <div
      className={`flex items-center justify-between px-4 py-4 ${
        isLast ? "border-b border-[#E5E5EA]" : ""
      }`}
    >
      <div className="max-w-[70%]">
        <div className="text-[14px] text-black">{title}</div>
        {subtitle && (
          <div className="text-[12px] text-[#8E8E93] mt-1 leading-snug">
            {subtitle}
          </div>
        )}
      </div>
      {children}
    </div>
  );
}

function IOSSwitch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition ${
        checked ? "bg-[#34C759]" : "bg-[#E5E5EA]"
      } ${disabled ? "opacity-40" : ""}`}
    >
      <span
        className={`inline-block h-6 w-6 transform rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}
