import { useState } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";

const NOTIFY_ITEMS = [
  "BT mode",
  "AUX mode",
  "PC mode",
  "Connect",
  "Disconnect",
  "TWS Connect",
  "Vol max",
  "BT Pair",
];

export default function TabThongBao() {
  const { data, update, save } = useSystemConfig();
  const [saving, setSaving] = useState(false);
  
  if (!data) {
    return <div className="p-6 text-gray-500">Loading...</div>;
  }

  const setItemField = (index, value) => {
    const newItems = [...data.Item_thong_bao];
    newItems[index] = value ? 1 : 0;
    update("Item_thong_bao", newItems);
  };

  const handleSave = async () => {
    setSaving(true);
    await save();
    setSaving(false);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl overflow-hidden text-[12px]">
      {/* ===== TITLE ===== */}
      <div className="sticky top-0 z-10 bg-white px-4 py-3 shadow-sm">
        <h1 className="text-[17px] font-bold tracking-tight text-black">
          Cấu hình Thông báo
        </h1>
      </div>

      {/* ===== MAIN CARD ===== */}
      <div className="flex-1 min-h-0 overflow-y-auto px-3 py-2 space-y-2 text-black">
        {/* ===== ENABLE ===== */}
        <Row
          title="Bật nhạc thông báo"
          subtitle="Tắt bật nhạc khởi động, thông báo,.."
        >
          <IOSSwitch
            checked={data.Thong_bao_en === 1}
            onChange={(v) => update("Thong_bao_en", v ? 1 : 0)}
          />
        </Row>

        {/* ===== VOLUME ===== */}
        <RowWin11 label="Volume thông báo">
          <div className="flex w-full items-center gap-3">
            <input
              type="range"
              min={0}
              max={16}
              value={data.Volume_thong_bao}
              onChange={(e) =>
                update("Volume_thong_bao", Number(e.target.value))
              }
              disabled={data.Thong_bao_en === 0}
              className="h-2 w-full cursor-pointer rounded-lg bg-gray-200 accent-blue-600"
            />
            <span className="w-8 text-sm text-black">
              {data.Volume_thong_bao}
            </span>
          </div>
        </RowWin11>

        {/* ===== LIST ===== */}
        <div className="border-gray-200 p-4">
          <div className="mb-3 text-sm font-medium text-black">
            Danh sách âm báo
          </div>

          {/* ===== GRID 2 COL ===== */}
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {NOTIFY_ITEMS.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between rounded-xl border border-gray-200 bg-white px-4 py-2 shadow-sm hover:bg-gray-50"
              >
                <span className="text-sm text-black">{item}</span>

                <Switch
                  checked={data.Item_thong_bao[idx] === 1}
                  onChange={(v) => setItemField(idx, v)}
                  disabled={data.Thong_bao_en === 0}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="sticky bottom-0 bg-white p-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <button
          onClick={handleSave}
          disabled={saving}
          className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-medium text-white transition ${
            saving
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 active:scale-95"
          }`}
        >
          {saving && (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
          )}
          {saving ? "Đang lưu..." : "Lưu cấu hình"}
        </button>
      </div>
    </div>
  );
}

/* ================= ROW ================= */
function RowWin11({ label, children }) {
  return (
    <div className="grid grid-cols-1 items-center gap-3 border-b border-gray-200 p-3 md:grid-cols-2">
      <div className="text-[14px] text-black">{label}</div>
      <div className="text-[12px] flex items-center gap-2">{children}</div>
    </div>
  );
}

/* ================= SWITCH ================= */
function Switch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`flex h-6 w-12 items-center rounded-full p-0.5 transition
        ${checked ? "bg-blue-600" : "bg-gray-300"}
        ${disabled ? "cursor-not-allowed opacity-40" : "cursor-pointer"}
      `}
    >
      <div
        className={`h-5 w-5 rounded-full bg-white shadow transition
          ${checked ? "translate-x-6" : ""}
        `}
      />
    </button>
  );
}

function Row({ title, subtitle, children, isLast }) {
  return (
    <div
      className={`flex items-center justify-between px-4 py-4 ${
        !isLast ? "border-b border-[#E5E5EA]" : ""
      }`}
    >
      <div className="max-w-[70%]">
        <div className="text-[14px] text-black">{title}</div>
        {subtitle && (
          <div className="text-[12px] text-[#8E8E93] mt-1 leading-snug">
            {subtitle}
          </div>
        )}
      </div>
      {children}
    </div>
  );
}

function IOSSwitch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition ${
        checked ? "bg-[#34C759]" : "bg-[#E5E5EA]"
      } ${disabled ? "opacity-40" : ""}`}
    >
      <span
        className={`inline-block h-6 w-6 transform rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}
