import { useState } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";

export default function TabPreamp() {
  const { data, update, save } = useSystemConfig();
  const [saving, setSaving] = useState(false);
  const [localBuoc, setLocalBuoc] = useState(data?.Buoc_eq);

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const { Vr_en, Pre_en, Pre_mode, Buoc_eq, Vr_log } = data;

  const handleSave = async () => {
    setSaving(true);
    await save();
    setSaving(false);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl overflow-hidden text-[12px]">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white px-4 py-3 shadow-sm">
        <h1 className="text-[17px] font-bold tracking-tight text-black">
          Cấu hình Preamp + Biến Trở
        </h1>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto px-3 py-2 space-y-2 text-black">
        {/* Bảng giá trị hiện tại */}
        <div className="mt-2 rounded-lg border ">
          <table className="min-w-full border-collapse border border-gray-300 text-center text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="border px-2 py-1">Tên Biến Trở / Preamp</th>
                <th className="border px-2 py-1">Chức năng</th>
                <th className="border px-2 py-1">Giá trị hiện tại</th>
              </tr>
            </thead>
            <tbody>
              <tr className="even:bg-gray-50">
                <td className="border px-2 py-1">VOLUME</td>
                <td className="border px-2 py-1">
                  Volume tổng
                  {Pre_mode === 1 ? " ( Biến Trở )" : " (App + Key)"}
                </td>
                <td className="border px-2 py-1">{Vr_log[0]}</td>
              </tr>

              <tr className="even:bg-gray-50">
                <td className="border px-2 py-1">Bass</td>
                <td className="border px-2 py-1">
                  Âm lượng giải tần thấp{" "}
                  {Pre_mode === 1 ? "( Biến Trở )" : "(App)"}
                </td>
                <td className="border px-2 py-1">{Vr_log[1]}</td>
              </tr>

              <tr className="even:bg-gray-50">
                <td className="border px-2 py-1">MID</td>
                <td className="border px-2 py-1">
                  Âm lượng giải tần trung{" "}
                  {Pre_mode === 1 ? "( Biến Trở )" : "(App)"}
                </td>
                <td className="border px-2 py-1">{Vr_log[2]}</td>
              </tr>

              <tr className="even:bg-gray-50">
                <td className="border px-2 py-1">Treble</td>
                <td className="border px-2 py-1">
                  Âm lượng giải tần cao{" "}
                  {Pre_mode === 1 ? "( Biến Trở )" : "(App)"}
                </td>
                <td className="border px-2 py-1">{Vr_log[3]}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Enable Biến Trở */}
        <Row title="Biến Trở" subtitle="Chỉ thay đổi được ở Cài đặt nhanh!">
          <IOSSwitch
            checked={Vr_en === 1}
            disabled
            onChange={(v) => update("Vr_en", v ? 1 : 0)}
          />
        </Row>

        {/* Enable Preamp */}
        <Row title="Preamp" subtitle="Chỉ thay đổi được ở Cài đặt nhanh!">
          <IOSSwitch
            checked={Pre_en === 1}
            disabled
            onChange={(v) => update("Pre_en", v ? 1 : 0)}
          />
        </Row>

        {/* Preamp mode */}
        <Row title="Preamp mode">
          <select
            value={Pre_mode}
            onChange={(e) => update("Pre_mode", Number(e.target.value))}
            className="h-9 rounded-lg border border-gray-300 px-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
          >
            <option value={0}>Điều chỉnh bằng APP + Key</option>
            <option disabled={Vr_en === 0} value={1}>
              Điều chỉnh bằng Biến trở
            </option>
          </select>
        </Row>

        {/* Độ lớn thay đổi */}
        <Row title="Độ lớn thay đổi">
          <input
            type="number"
            value={localBuoc}
            onChange={(e) => setLocalBuoc(e.target.value)}
            onBlur={() => {
              const num = Number(localBuoc);

              if (!isNaN(num) && num >= 3 && num <= 10) {
                update("Buoc_eq", num);
              } else {
                setLocalBuoc(Buoc_eq); // trả lại giá trị cũ nếu sai
              }
            }}
            disabled={Pre_en === 0}
            min={3}
            max={10}
            step={1}
            className="w-16 text-center rounded border px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-400"
          />
          <span>dB</span>
        </Row>

        {/* Ghi chú khách hàng */}
        <div className="mt-4 rounded border bg-gray-50 p-3 text-sm">
          <p className="mb-1 font-semibold">Ghi chú:</p>
          <ul className="list-disc pl-5">
            <li>
              <em className="text-blue-500">Biến trở</em> chỉnh được: Volume
              tổng + Preamp (Bass, Mid, Treble) khi chọn Preamp là Biến trở
              Bass, Mid, Treble.
            </li>
            <li>
              <em className="text-blue-500">App</em> có thể chỉnh được: Preamp
              (Bass, Mid, Treble) , có thể chỉnh Volume khi không dùng Biến trở
            </li>
            <li>
              <em className="text-blue-500">Preamp</em> Chỉnh{" "}
              <em className="text-red-500">tần số</em> và{" "}
              <em className="text-red-500"> độ cắt </em> ở tab Preamp ngoài menu
              chính
            </li>
          </ul>
        </div>
      </div>

      {/* SAVE BUTTON */}
      <div className="sticky bottom-0 bg-white p-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <button
          onClick={handleSave}
          disabled={saving}
          className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-medium text-white transition ${
            saving
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 active:scale-95"
          }`}
        >
          {saving && (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
          )}
          {saving ? "Đang lưu..." : "Lưu cấu hình"}
        </button>
      </div>
    </div>
  );
}

function Row({ title, subtitle, children, isLast }) {
  return (
    <div
      className={`flex items-center justify-between px-4 py-4 ${
        !isLast ? "border-b border-[#E5E5EA]" : ""
      }`}
    >
      <div className="max-w-[70%]">
        <div className="text-[14px] text-black">{title}</div>
        {subtitle && (
          <div className="text-[13px] text-[#8E8E93] mt-1 leading-snug">
            {subtitle}
          </div>
        )}
      </div>
      {children}
    </div>
  );
}

/* ========== iOS Switch ========== */

function IOSSwitch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition ${
        checked ? "bg-[#34C759]" : "bg-[#E5E5EA]"
      } ${disabled ? "opacity-40" : ""}`}
    >
      <span
        className={`inline-block h-6 w-6 transform rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}
