import { useState } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";

export default function TabVolume() {
  const { data, update, save } = useSystemConfig();
  const [saving, setSaving] = useState(false);

  if (!data) return null;

  const { Volume_tong, Nho_volume, Dongbo_volume, Key_en, Vr_en } = data;

  const rememberDisabled = Key_en === 0 && Vr_en === 1;
  const syncDisabled = Vr_en === 1;

  const handleSave = async () => {
    setSaving(true);
    await save();
    setSaving(false);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl overflow-hidden text-[12px]">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white px-4 py-3 shadow-sm">
        <h1 className="text-[17px] font-bold tracking-tight text-black">
          Âm lượng
        </h1>
      </div>

      {/* Group */}
      <div className="flex-1 min-h-0 overflow-y-auto px-3 py-2 space-y-2 text-black">
        {/* Volume */}
        <div className="px-4 py-4 border-b border-[#E5E5EA]">
          <div className="flex justify-between items-center mb-3">
            <span className="text-black">Volume tổng</span>
            <span className="text-[#007AFF] font-medium">
              {Volume_tong}
            </span>
          </div>

          <input
            type="range"
            min={0}
            max={16}
            value={Volume_tong}
            onChange={(e) => update("Volume_tong", Number(e.target.value))}
            className="w-full h-1 accent-[#007AFF]"
          />
        </div>

        {/* Nhớ volume */}
        <Row
          title="Nhớ volume"
          subtitle="Chỉ hoạt động khi bật phím và tắt biến trở"
        >
          <IOSSwitch
            checked={Nho_volume === 1}
            disabled={rememberDisabled}
            onChange={(v) => {
              update("Nho_volume", v ? 1 : 0);
              if (v) update("Dongbo_volume", 0);
            }}
          />
        </Row>

        {/* Đồng bộ */}
        <Row
          title="Đồng bộ volume Bluetooth"
          subtitle="Chỉ hoạt động khi tắt biến trở"
          isLast
        >
          <IOSSwitch
            checked={Dongbo_volume === 1}
            disabled={syncDisabled}
            onChange={(v) => {
              update("Dongbo_volume", v ? 1 : 0);
              if (v) update("Nho_volume", 0);
            }}
          />
        </Row>
      </div>

      {/* Save Button */}
      <div className="sticky bottom-0 bg-white p-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <button
          onClick={handleSave}
          disabled={saving}
          className={`flex w-full items-center justify-center gap-2 rounded-xl py-3 font-medium text-white transition ${
            saving
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 active:scale-95"
          }`}
        >
          {saving && (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
          )}
          {saving ? "Đang lưu..." : "Lưu cấu hình"}
        </button>
      </div>

    </div>
  );
}

/* ========== Row ========== */

function Row({ title, subtitle, children, isLast }) {
  return (
    <div
      className={`flex items-center justify-between px-4 py-4 ${
        !isLast ? "border-b border-[#E5E5EA]" : ""
      }`}
    >
      <div className="max-w-[70%]">
        <div className="text-[14px] text-black">{title}</div>
        {subtitle && (
          <div className="text-[13px] text-[#8E8E93] mt-1 leading-snug">
            {subtitle}
          </div>
        )}
      </div>
      {children}
    </div>
  );
}

/* ========== iOS Switch ========== */

function IOSSwitch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition ${
        checked ? "bg-[#34C759]" : "bg-[#E5E5EA]"
      } ${disabled ? "opacity-40" : ""}`}
    >
      <span
        className={`inline-block h-6 w-6 transform rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}
