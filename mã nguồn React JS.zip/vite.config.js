import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from "path";

// https://vite.dev/config/
export default defineConfig({
  base: "./",
  plugins: [react()],
  resolve: {
    alias: {
      "@src": path.resolve(__dirname, "src"),
      "@core": path.resolve(__dirname, "src/core"),
      "@effects": path.resolve(__dirname, "src/effects"),
      "@store": path.resolve(__dirname, "src/store"),
      "@hooks": path.resolve(__dirname, "src/hooks"),
      "@components": path.resolve(__dirname, "src/components"),
      "@modal": path.resolve(__dirname, "src/modal"),
      "@utils": path.resolve(__dirname, "src/utils"),
    },
  },
})
